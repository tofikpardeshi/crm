@extends('main')


@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Update-Leads-Status</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Update Leads Status -> {{ $Leads->lead_name }}</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="d-flex justify-content-end">
                                    <a type="button" class="btn btn-danger waves-effect waves-light  "
                                        href="{{ url('employee-leads/' . $emp_id->id . '/' . $location_id->id) }}">Back</a>
                                </div>
                                @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible text-center">
                                        <h5>{{ Session::get('success') }}</h5>
                                    </div>
                                @endif
                                <form method="POST" action="{{ url('status-update/' . $Leads->id) }}">
                                    @csrf

                                    {{-- <input type="text" name="lead_id" id="lead_id"> --}}

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Status Date</label>
                                                <input type="datetime-local" id="date" step="any" value="@php  echo date('Y-m-d\TH:i:s') @endphp"
                                                    name="status_date" class="form-control" required>
                                                @error('lead_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Lead Status</label>
                                                <select name="lead_status" class="selectpicker" data-style="btn-light"
                                                    id="lead_status" placeholder="Select Lead Status" selected>
                                                    @foreach ($LeadStatus as $LeadStatusUpdate)
                                                        @if ($LeadStatusUpdate->name == $Leads->lead_status)
                                                            <option value="{{ $LeadStatusUpdate->name }}" selected>
                                                                {{ $LeadStatusUpdate->name }}</option>
                                                        @else
                                                            <option value="{{ $LeadStatusUpdate->name }}">
                                                                {{ $LeadStatusUpdate->name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Next Follow Up Date</label>
                                                <input type="datetime-local" id="date" name="next_follow_up_date" step="any"
                                                    value="{{ now()->setTimezone('T')->format('Y-m-dTh:m') }}"
                                                    class="form-control"
                                                    min="{{ date('Y-m-d\TH:i:s', strtotime(Carbon\Carbon::today())) }}">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            @php
                                                $updateSutatus = DB::table('lead_status_histories')
                                                    ->where('lead_id', $Leads->id)
                                                    ->orderBy('id', 'DESC')
                                                    ->first(); 
                                            @endphp

                                                @if($updateSutatus ==  null) 
                                                <div class="form-group mb-3">
                                                    <label for="example-select">Project Name <span
                                                            class="text-danger">*</span></label>
                                                    <select name="project_name[]" class="selectpicker" data-style="btn-light"
                                                        style="height:20px!important" id="project_name" multiple>
                                                        @foreach ($projectLists as $projectList)
                                                            <option value="{{ $projectList->id }}">
                                                                {{ $projectList->project_name }}</option>
                                                        @endforeach
                                                    </select>
    
                                                    @error('project_name')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                </div>
                                                @else

                                                    @php
                                                        $selected = explode(',', $updateSutatus->project_id);
                                                    @endphp
                                                    

                                                    <div class="form-group mb-3">
                                                        <label for="example-select">Project Name <span
                                                                class="text-danger">*</span></label>
                                                        <select name="project_name[]" class="selectpicker" data-style="btn-light"
                                                            style="height:20px!important" id="project_name" multiple>
                                                            @foreach ($projectLists as $projectList)
                                                                <option value="{{ $projectList->id }}"
                                                                    {{ in_array($projectList->id, $selected) ? 'selected' : '' }}>
                                                                    {{ $projectList->project_name }}</option>
                                                            @endforeach
                                                        </select>
        
                                                        @error('project_name')
                                                            <small class="text-danger">{{ $message }}</small>
                                                        @enderror
                                                    </div>
                                                @endif
 
                                            
                                        </div>


                                        {{-- <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label>Follow Up Time</label>
                                                <input type="time" id="time" name="follow_up_time" class="form-control">
                                            </div>
                                        </div> --}}

                                        <div class="col-md-12">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Customer Interaction</label>
                                                <textarea class="form-control" id="customer_interaction" name="customer_interaction" rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button name="submit" value="submit" type="submit"
                                            class="btn btn-primary waves-effect waves-light">Update Lead</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div> <!-- end card-body-->

            </div> <!-- end card-->


        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection
