@extends('main')


@section('dynamic_page')
    <div class="container-fluid">



        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Profile</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Profile</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        @if (session()->has('error'))
                            <div class="alert alert-danger">
                                {{ session()->get('error') }} </div>
                        @endif
                        @if (Session::has('success'))
                            <div class="alert alert-success alert-dismissible text-center">
                                <h5>{{ Session::get('success') }}</h5>
                            </div>
                        @endif
                        <h4 class="mb-3 header-title">Profile Details</h4>

                        <form class="form-horizontal" method="post" action="{{ route('update-profile') }}" enctype="multipart/form-data">
                            @csrf


                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-form-label">Name</label>
                                        <input type="text" name="name" value="{{ Auth::user()->name }}"
                                            class="form-control" id="first_name" placeholder="Enter Name" required> 
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="email" class=" col-form-label">Email</label>
                                        <input type="email" name="email" value="{{ Auth::user()->email }}"
                                            class="form-control" id="email" placeholder="email" required>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="example-password" class=" col-form-label">Aadhar Number</label>
                                        <input type="text" name="addhar_number" id="addhar_number" class="form-control"
                                        value="{{ $employeeData['addhar_number'] }}">

                                        @error('addhar_number')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>
                                 

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="pan-number">PAN Number</label>
                                        <input type="text" name="pan_Number" class="form-control" value="{{ $employeeData['pan_Number'] }}">
                                        @error('pan_Number')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="Date of Brith">Date of Brith</label>
                                        <input type="date" name="date_of_brith" class="form-control" value="{{ $employeeData['date_of_brith'] }}" min="2004-01-03">
                                        @error('date_of_brith')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-password">Address</label>
                                        <input type="text" name="current_address" id="address" class="form-control" value="{{ $employeeData['current_address'] }}">

                                        @error('address')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="Date of Brith">Education Background</label>
                                        <input type="text" name="education_background" class="form-control" value="{{ $employeeData['education_background'] }}">
                                        @error('education_background')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="Blood Group">Blood Group</label>
                                        <input type="text" name="blood_group" class="form-control" value="{{ $employeeData['blood_group'] }}">
                                        @error('blood_group')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="Emergeny_Contact_Number ">
                                            Emergency Contact Number
                                        </label>
                                        <input type="text" name="emergeny_contact_name" class="form-control" value="{{ $employeeData['emergeny_contact_name'] }}"
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" maxlength="10" >
                                        @error('emergeny_contact_number')
                                            <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="Personal-Email">Personal Email</label>
                                        <input type="email" name="personal_email" class="form-control" value="{{ $employeeData['personal_email'] }}">

                                    </div>
                                </div>
 
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="profilePicture" class="col-form-label">Profile Picture</label>
                                        <input type="file" name="profile_pic" id="">
                                        <div class="dropzone-previews mt-3" id="file-previews"></div>

                                    </div>
                                </div>
 
                                {{-- <div class="row">
                                    <div class="col-lg-3">
                                        <img id="image" src="{{ url('') }}/assets/images/users/no.png" alt="Picture"
                                            class="img-fluid">
                                    </div>
                                </div> --}} 
 
                        </div>
                                    <button name="submit" value="submit" type="submit"
                                        class="btn btn-primary waves-effect waves-light">Update
                                        Profile</button>
                                  
                        </form>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div>
        </div>

        <!-- end row -->

        <div class="row">

            <div class="col-lg-12">
                <div class="card">

                    <div class="card-body">

                        <h4 class="mb-3 header-title">Change Password</h4>

                        <form class="form-horizontal" action="{{ route('change-password') }}" method="post">
                            @csrf
                            <div class="form-group row mb-3">
                                <label for="inputEmail3" class="col-3 col-form-label">Old Password</label>
                                <div class="col-9">
                                    <input type="password" name="old_password" class="form-control" id="oldPassword"
                                        placeholder="Old Password">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label for="inputPassword3" class="col-3 col-form-label">New Password</label>
                                <div class="col-9">
                                    <input type="password" name="new_password" class="form-control" id="inputnewPassword3"
                                        placeholder="New Password">
                                </div>
                            </div>
                            <div class="form-group row mb-3">
                                <label for="inputPassword5" class="col-3 col-form-label">Re Password</label>
                                <div class="col-9">
                                    <input type="password" name="confirm_password" class="form-control"
                                        id="inputPassword5" placeholder="Retype Password">
                                </div>
                            </div>
                            <div class="form-group mb-0 justify-content-end row">
                                <div class="col-9">
                                    <button type="submit" name="submit" value="submit"
                                        class="btn btn-primary waves-effect waves-light">Change Password</button>
                                </div>
                            </div>
                        </form>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div>
        </div>

    </div> <!-- container -->
@endsection
