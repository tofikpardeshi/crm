@extends('main')


@section('dynamic_page')
    <!-- Start Content-->
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Leads</li>
                        </ol>
                    </div>
                    <h4 class="page-title"> {{ $location_names->location }} > 
                        <span class="text-capitalize">
                        {{ $emp_names->employee_name }}</span> > Leads</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <form class="form-inline">
                                    <div class="form-group mb-2">
                                        <label for="inputPassword2" class="sr-only">Search</label>
                                        <input type="search" class="form-control" id="inputPassword2"
                                            placeholder="Search...">
                                    </div>
                                </form>
                            </div>
                            <div class="col-sm-8">
                                <div class="text-sm-right">
                                    {{-- <button type="button" class="btn btn-success waves-effect waves-light mb-2 mr-1"><i
                                            class="mdi mdi-cog"></i></button> --}}
                                    <a type="button" class="btn btn-danger waves-effect waves-light mb-2"
                                        href="{{ route('create-leads') }}">Add New</a>
                                </div>
                            </div><!-- end col-->
                        </div>

                        <div class="table-responsive">
                            @if (session()->has('Delete'))
                                <div class="alert alert-danger text-center">
                                    {{ session()->get('Delete') }} </div>
                            @endif
                            @if (session()->has('success'))
                                <div class="alert alert-success text-center">
                                    {{ session()->get('success') }} </div>
                            @endif
                            <table class="table table-centered table-nowrap table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Creation Date</th>
                                        <th>Customer</th>
                                        <th>Mobile</th>
                                        <th>Last Contacted</th>
                                        <th>Follow Up Date</th>
                                        <th>Project Type</th>
                                        <th>Customer Type</th>
                                        <th>Budget</th>
                                        <th>Last Summary</th>
                                         {{-- <th>Contact Number</th> --}}
                                       {{-- <th>Follow Up Date</th> --}}
                                        {{-- <th>Project Type</th>
                                        <th>Assigned To</th>
                                        <th>Lead Status</th> --}}
                                        <th style="width: 82px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($emplyeeLeadData as $lead) 
                                        <tr>
                                             <td>
                                                {{ \Carbon\Carbon::parse($lead->date)->format('j-F-Y') }}
                                            </td>
                                            <td class="table-user">
                                                {{-- <img src="{{ url('') }}/assets/images/users/user-4.jpg" alt="table-user"
                                                class="mr-2 rounded-circle"> --}}
                                                <a href="{{ url('lead-status/'.$lead->id) }}" class="text-body font-weight-semibold updateStatus" 
                                                    value="{{ $lead->id }}" >{{ $lead->lead_name }}</a>
                                            </td>
                                            {{-- <td class="table-user">
                                                {{-- <img src="{{ url('') }}/assets/images/users/user-4.jpg" alt="table-user"
                                                class="mr-2 rounded-circle"> --}}
                                                {{-- <a href="#" class="text-body font-weight-semibold updateStatus" data-toggle="modal"
                                                    value="{{ $lead->id }}"
                                                    data-target="#exampleModal-{{ $lead->id }}">{{ $lead->lead_name }}</a>
                                            </td> --}}
                                            {{-- contact_number --}}
                                            <td>
                                                <a class="text-muted" href="tel:{{ $lead->contact_number }}" >
                                                    {{ $lead->contact_number }}</a> 
                                            </td>
                                            {{-- last Connect Date --}}
                                            <td>
                                                {{ \Carbon\Carbon::parse($lead->last_contacted)->format('j-F-Y') }}
                                            </td>
                                            {{-- fllow up Date --}}
                                            <td>
                                                {{ \Carbon\Carbon::parse($lead->next_follow_up_date)->format('j-F-Y') }}
                                            </td>
                                            {{-- project type  --}}
                                            <td>
                                                {{ $lead->project_type }}
                                            </td>
                                            {{-- customer type --}}
                                            <td>
                                                {{ $lead->property_requirement }}
                                            </td>
                                           
                                             <td>
                                                {{ $lead->budget }}
                                            </td>
                                            
                                           
                                            {{-- <td>
                                                {{ $lead->contact_number }}
                                            </td>
                                            <td>
                                                {{ $lead->source }}
                                            </td>
                                            <td>
                                                {{ $lead->project_type }}
                                            </td>
                                            <td>
                                                {{ $lead->employee_name }}
                                            </td>
                                            <td>
                                                {{ $lead->lead_status }}
                                            </td> --}}
                                          
                                          {{-- Lead Status  lead_status--}}
                                           <td>
                                            {{ $lead->lead_status }}
                                            </td>
                                          
                                          
                                            <td>

                                                {{-- <a data-toggle="tooltip" data-placement="top" title="Check Status"
                                                    href="{{ url('lead-status/' . $lead->id) }}" class="action-icon">
                                                    <img style="width:20px; margin-bottom:2px"
                                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAABmJLR0QA/wD/AP+gvaeTAAAE0ElEQVRoge2Zy09bRxTGv3OvTUwUG5pbkBDhWYlHKtFWjtpNF5BVCVhgEK7asuiiihqRdpFl1UquVPUPCAKRSl01i9YGTGIg6qKBdUSkVqgEkBLAkFQp4WEbgcH2PV2UqMjXjxnb0EX4LWfO4zuauY8zA5xyyqsN5SNIj6dH3TPF3mVFb1GY7DrQQEAZAecAgIEdMD0j4gUGZkhXpuyzTQ/cbreea+6cCugY66jQdaWPgV4Ql0u6r4H4djyuDtzrHl3LVkNWBbR6ekpM5uh3DHwKoCDb5IccEPCjiekbX5dvQ9ZZugDHWMfHzNQP4LysbwY2QNw33nnnFxkn4QLst66ay0rWB0H8mbw2CYiHdoqCX0y3TMeEzEWMHH7HWY6pwwBacxInCBFPQNVdfod/N5OtksnAfuuq+STFAwAztSGueJqnmk2ZbDMWUFayPogTFP8SZmqzbhffzGSXdgu1jzo/AfHt/MmSh4AP/c4xT5r55DhHnVqUeB7A68eiTJwNMsUb/A7/i2STKbdQjPh7/P/iAUDjuOJONZl0BVpHui6oiv4YWXykaotqcFFrQIW1AtYCKwAgvB9GILyKuc1HWAouy4YEgH2YYm+MO8afJk4kfcpNxNdZUrxm0dBW24pKa4VxrlCDVqjhndK3sRIOYPLJPWxENmXCn0HM1Afgq8QJwwq43W5l5q3fVwBcEI1eaauEq64bFtUiZB+JR+BdGMFKOCCaAmB6WhgzVXld3vjRYcMzMNP0x3uQEK9ZNCnxAGBRLeip78Z5y2vCPiAu3zNH7YnDhgJY0VvEowJXaj6QEv8Si2pBW+0VKR9iupw4ZiiAdOWSaMCaompU2SqlRBylylqJGlu1sD0DmVcAQJ1owDe1i8LJU9GoNQrbEnF94pixAOIy0YAVVuFHJSVVSd5aqWDAoC3ZCpwTDWgz24STp4xRIBXDmjiQ8WfuuNGRW1ucrIAdUedQNJRTcgAIHwinA4Bw4oCxAKa/RKOthldlkiclIPExI8CgzfgaJV4QDfjni3nh5KmY23wkbkwwJDQUoBM/FI23FFrCcmhFXEACgVAAy0Fxfx1GbYYClLh6X0bExNIkdmMZW1cDe7EI/E8mpXySaTMUYJ9tegBAeHNvRbYxsuhDJB4RFrIXi8C7OIyt/S1hHwAB+2yTYQXUxIHp6Wmu+6i+FKD3RSMHD4KY31xA6dlSFJ8pSmu7HFqBZ2EYz3efi4YHABDTwA/Xhn4zjCczzqWhqbFVo1FrRKW1AkWHH6ngQeiwoZmT2vNHSNnQpOyJHb7OQQauZZMt3xDQ73eOfZlsLuWX+CBq/hrA+rGpEmfDxPRtqsmUBfzq8m4yU9KqTxTiz9Md+qb9F5ro8v0M4qH8qxKDgP7xzjvD6Wwy/swVHhRcB5Mvf7KEGQ8Xb9/IZJSxAK/LGydzrJeIJ/KjSwh/YdTsEjmhFj5eb55qNlm3i28e95uJgP5w8faNvB6vH8Xh63QxMID8n9r9fXjBkXbPJyLd0PidY55o1FwP4gEA+7L+BogjBPSzOdogKx7I8ZKv3d9efnhi1gtAvLn9lwAT/6QSD97tuPssWw15uWY9PM27REyXGbATcT0D5fivv94B0xqARVb0GSWu3rfPNj3MxzXrKae86vwDmbWeftNnJZcAAAAASUVORK5CYII=" />
                                                </a> --}}

                                                <a href="{{ url('edit-leads/' . $lead->id) }}" class="action-icon">
                                                    <i class="mdi mdi-square-edit-outline">
                                                    </i></a>

                                                <a href="{{ url('lead-stutas-update/' . $lead->id) }}">
                                                    <i class='far fa-lightbulb' style="font-size: 17px"></i>
                                                 {{-- <button type="button" class="btn btn-primary updateStatus"
                                                  value="{{ $lead->id }}">
                                                    status
                                                </button> --}}
                                                </a>  
                                                {{-- <a href="{{ url('/lead-delete/' . $lead->id) }}" class="action-icon">
                                                    <i class="mdi mdi-delete"></i></a> --}}

                                                {{-- <button type="button" class="btn btn-primary updateStatus"
                                                    data-toggle="modal" value="{{ $lead->id }}"
                                                    data-target="#exampleModal">
                                                    status
                                                </button> --}}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                           
                        </div>
                        {{-- <span>{{ $leads->links() }}</span> --}}
                        <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                            {{ $emplyeeLeadData->links('pagination::bootstrap-4') }}
                        </ul>

                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->


        </div>
        <!-- end row -->

    </div> <!-- container -->


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Status</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                {{-- <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <form method="POST" action="{{ url('status-update') }}">
                                @csrf

                                <input type="hidden" name="lead_id" id="lead_id">

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="simpleinput">Date</label>
                                            <input type="date" id="date" name="date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">

                                            <label for="example-select">Lead Status</label>
                                            <select name="lead_status" class="selectpicker" data-style="btn-light"
                                                id="lead_status" placeholder="Select Lead Status" selected>

                                                @foreach ($LeadStatus as $LeadStatusData)
                                                    <option value="{{ $LeadStatusData->name }}">
                                                        {{ $LeadStatusData->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="simpleinput">Next Follow Up Date</label>
                                            <input type="date" id="date" name="next_follow_up_date" class="form-control">
                                        </div>
                                    </div> 
                                    
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="simpleinput">Follow Up Time</label>
                                            <input type="date" id="date" name="follow_up_time" class="form-control">
                                        </div>
                                    </div> 

                                    {{-- <div class="col-md-12">
                                        <div class="form-group mb-3">
                                            <label for="simpleinput">Remarks of Caller</label>
                                            <textarea class="form-control" id="remarks_of_caller" name="remarks_of_caller" rows="3"></textarea>
                                        </div>
                                    </div> --}}
                                {{-- </div>
                                <div class="modal-footer">
                                    <button name="submit" value="submit" type="submit"
                                        class="btn btn-primary waves-effect waves-light">Update Leads</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>   --}}

            </div>
        </div>
    </div>
@endsection

@section('scripts')
    {{-- modal in latavel --}}
    {{-- <script>
        $(document).ready(function() {
            $(document).on('click', '.updateStatus', function() {
                var lead_id = $(this).val();
                $('#lead_id').val(lead_id)
                $('#exampleModal').modal('show');
            })
        })
    </script> --}}
    {{-- modal in latavel End --}}
@endsection
