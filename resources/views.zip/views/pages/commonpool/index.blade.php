@extends('main')


@section('dynamic_page')
    <!-- Start Content-->
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Common Pool</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Common Pool</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">

                @if (Session::has('error'))
                    <div class="alert alert-danger alert-dismissible text-center">
                        <h5>{{ Session::get('error') }}</h5>
                    </div>
                @endif

                @if (Session::has('success'))
                    <div class="alert alert-success alert-dismissible text-center">
                        <h5>{{ Session::get('success') }}</h5>
                    </div>
                @endif
                <div class="card">
                    <div class="card-body">
                        <div class="row no-gutters">
                            <div class="col-lg-3">
                                <form method="post" action="{{ url('assign-common-pool') }}">
                                    @csrf
                                    <input type="hidden" id="demo" name="cp">
                                    <div class="form-group ">
                                        <label>Assign Employee</label>
                                        <select name="common_pool" class="form-control" id="common_pool"
                                            data-style="btn-light">
                                            @foreach ($employees as $employee)
                                                <option value="{{ $employee->id }}">
                                                    {{ $employee->employee_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                            </div>
                            <div class="col-lg-3 " style="margin-top: 28px;">
                                <button name="submit" value="submit" type="submit"
                                    class="btn  btn-primary waves-effect waves-light delete_all"
                                    data-url="{{ url('assign-common-pool') }}">
                                    Assign Employee</button>
                            </div>
                            </form>

                        </div>


                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th style="width: 82px;">
                                            <input type="checkbox" name="test[]" id="master">
                                        </th>
                                        <th>Creation Date</th>
                                        <th>Customer</th>
                                        <th>History Count</th>
                                        <th>Assigned Lead</th>
                                        <th>Mobile</th>
                                        <th>Last Contacted</th>
                                        <th>Follow Up Date</th>
                                        <th>Project Type</th>
                                        <th>Customer Type</th>
                                        <th>Lead Type</th>
                                        <th>Budget</th>
                                        <th>Last Summary</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($CommonPolls as $CommonPoll)
                                        <!-- Modal -->
                                        {{-- <div class="modal fade" id="exampleModal-{{ $CommonPoll->id }}" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Update Status</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <form method="post"
                                                                    action="{{ url('employee-assing-comoon-poll') }}">
                                                                    @csrf


                                                                    <input type="hidden" name="commonpooID"
                                                                        value="{{ $CommonPoll->id }}">

                                                                    <div class="form-group mb-3">

                                                                        <label>Assign Employee</label>
                                                                        <select name="common_pool" class="form-control"
                                                                            id="common_pool" data-style="btn-light">

                                                                            @foreach ($employees as $employee)
                                                                                <option value="{{ $employee->id }}">
                                                                                    {{ $employee->employee_name }}
                                                                                </option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button name="submit" value="submit" type="submit"
                                                                            class="btn btn-primary waves-effect waves-light">
                                                                            Assign Employee</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div> --}}
                                        <tr>
                                            <td class="table-user">
                                                {{-- <a href="{{ url('employee-assing-comoon-poll/' . $CommonPoll->id) }}"
                                                    class="action-icon" data-toggle="modal"
                                                    value="{{ $CommonPoll->id }}"
                                                    data-target="#exampleModal-{{ $CommonPoll->id }}"> --}}
                                                <input type="checkbox" name="test[]" class="sub_chk"
                                                    value="{{ $CommonPoll->id }}" data-id="{{ $CommonPoll->id }}">
                                                {{-- </a> --}}

                                            </td>

                                            <td>
                                                {{ \Carbon\Carbon::parse($CommonPoll->date)->format('j-F-Y H:i') }}
                                            </td>

                                            <td>
                                                <a href="#" class="text-body font-weight-semibold updateStatus"
                                                    value="{{ $CommonPoll->lead_name }}">
                                                    {{ $CommonPoll->lead_name }}</a>
                                            </td>

                                            <td>
                                                @php
                                                    $LeadCount = DB::table('lead_status_histories')
                                                        ->where('lead_id', $CommonPoll->id)
                                                        ->count();
                                                @endphp
                                                <span>{{ $LeadCount }}</span>
                                            </td>
                                            <td>
                                                {{ $CommonPoll->employee_name }}
                                            </td>
                                            <td>
                                                {{ $CommonPoll->contact_number }}
                                            </td>
                                            <td>
                                                {{ $CommonPoll->last_contacted }}
                                            </td>
                                            <td>
                                                {{ $CommonPoll->next_follow_up_date }}
                                            </td>

                                            <td>
                                                {{ $CommonPoll->project_type }}
                                            </td>

                                            <td>
                                                @php
                                                    $customerType = DB::table('leads')
                                                        ->join('buyer_sellers', 'buyer_sellers.id', '=','leads.buyer_seller')
                                                        ->select('leads.*', 'buyer_sellers.name')
                                                        ->where('leads.id', $CommonPoll->id)
                                                        ->first();
                                                @endphp
                                                {{ $customerType->name }}
                                            </td>

                                            <td>
                                                @php
                                                    $lead_type_bif = DB::table('lead_type_bifurcation')
                                                        ->where('id', $CommonPoll->lead_type_bifurcation_id)
                                                        ->first();
                                                @endphp
                                                {{ $lead_type_bif->lead_type_bifurcation }}

                                            </td>
                                            <td>
                                                {{ $CommonPoll->budget }}
                                            </td>

                                            <td>
                                                {{ $CommonPoll->lead_status }}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                            {{ $CommonPolls->links('pagination::bootstrap-4') }}
                        </ul>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->

        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection
@section('scripts')
    <script>
        $(document).ready(function() {
             var allVals = [];
            $('#master').on('click', function(e) {
                if ($(this).is(':checked', true)) {
                    $(".sub_chk").prop('checked', true);
                } else {
                    $(".sub_chk").prop('checked', false);
                }
            });

            $('.sub_chk').on('click', function(e) {
                if ($(this).is(':checked', true)) {

                    // $("#master").prop('checked', false);
                } else {
                    $("#master").prop('checked', false);
                }
            });



            $('.delete_all').on('click', function(e) { 
                $(".sub_chk:checked").each(function() {
                    allVals.push($(this).attr('data-id'));
                    // alert 
                });
                
                if (allVals.length <= 0  ) { 
                    alert("Please select row.");
                } else {
                    var check = true;
                    if (check == true) {
                        var join_selected_values = allVals.join(",");

                        // alert(join_selected_values);
                        
                        demo.value = join_selected_values;

                        // $.ajax({
                        //     url: "{{ route('assign-common-pool') }}",
                        //     type: 'POST',
                        //     headers: {
                        //         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        //     },
                        //     data: 'ids=' + join_selected_values,  
                        // });
                        // $.each(allVals, function(index, value) {
                        //     $('table tr').filter("[data-row-id='" + value + "']").remove();
                        // });
                    }
                }
            });

        });
    </script>
@endsection
