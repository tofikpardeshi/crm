@extends('main')
@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Contacts</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Leads Create</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            {{-- More Links: <span class="fa fa-plus add"></span>
            <div class="appending_div">
                <div>
                    Link URL: <input type="text" name="lead_name[]"> &nbsp; Link Name: <input type="text"
                        name="contact_number[]">
                </div>
            </div> --}}
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible text-center">
                                        <h5>{{ Session::get('success') }}</h5>
                                    </div>
                                @endif
                                <form method="post" action={{ route('leads-create') }}>
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Date <span class="text-danger">*</span></label>
                                                <input type="datetime-local" class="form-control" id="training_date"
                                                    value="@php  echo date('Y-m-d\TH:i:s') @endphp" name="date" step="any"
                                                    value={{ old('date') }}>
                                                @error('date')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-4 wrapper">

                                            <div class="form-group mb-3">

                                                <label for="simpleinput">Customer Name<span
                                                        class="text-danger">*</span></label>
                                                {{-- <span class="fa fa-plus add_fields" id="Array_name"
                                                    style="cursor: pointer"></span> --}}
                                                <input type="text" name="lead_name" class="form-control"
                                                    value={{ old('lead_name') }}>
                                                @error('lead_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4 wrapper1">

                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Contact Number <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="contact_number"
                                                    value="{{ old('contact_number') }}" class="form-control" 
                                                    >
                                                @error('contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                    <input type="hidden" name="contact_number"
                                                        value="{{ $a = old('contact_number') }}">
                                                    @php
                                                        $Lead = App\Models\Lead::where('contact_number', $a)
                                                            ->select('id')
                                                            ->first();
                                                    @endphp
                                                    @if ($message == 'The contact number has already been taken.' . old('contact_number'))
                                                        <div class="d-flex justify-content-end">
                                                            <a href="{{ url('lead-status/' . $Lead->id) }}">
                                                                View Detail
                                                            </a>
                                                        </div>
                                                    @else
                                                    @endif
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Customer Requirement <span
                                                        class="text-danger">*</span></label>
                                                <select name="project_type[]" class="selectpicker" data-style="btn-light"
                                                    style="height:20px!important" id="project_type" multiple>

                                                    @foreach ($projectTypes as $projectType)
                                                        <option value="{{ $projectType->project_type }}"
                                                            {{ collect(old('project_type'))->contains($projectType->project_type) ? 'selected' : '' }}>
                                                            {{ $projectType->project_type }}</option>
                                                    @endforeach
                                                </select>

                                                @error('project_type')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Buying Location <span
                                                        class="text-danger">*</span></label>
                                                <select name="location_of_leads" class="selectpicker"
                                                    data-style="btn-light" id="example-select">
                                                    @foreach ($locations as $locations)
                                                        <option value="{{ $locations->id }}"
                                                            {{ collect(old('location_of_leads'))->contains($locations->id) ? 'selected' : '' }}>
                                                            {{ $locations->location }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('location_of_leads')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>


                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Source <span
                                                        class="text-danger">*</span></label>
                                                <select name="source" class="selectpicker" data-style="btn-light"
                                                    id="example-select">
                                                    @foreach ($SourceTypes as $SourceType)
                                                        <option value="{{ $SourceType->source_types }}"
                                                            {{ collect(old('source'))->contains($SourceType->source_types) ? 'selected' : '' }}>
                                                            {{ $SourceType->source_types }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('source')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Lead Assigned To <span
                                                        class="text-danger">*</span></label>
                                                <select name="assign_employee_id" class="selectpicker"
                                                    data-style="btn-light" id="example-select">

                                                    @foreach ($employees as $employee)
                                                        <option value="{{ $employee->id }}"
                                                            {{ $employee->user_id == Auth::user()->id ? 'selected' : '' }}
                                                            {{ collect(old('assign_employee_id'))->contains($employee->id) ? 'selected' : '' }}>
                                                            {{ $employee->employee_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('assign_employee_id')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Lead Status <span
                                                        class="text-danger">*</span></label>
                                                <select name="lead_status" class="selectpicker" data-style="btn-light"
                                                    id="example-select">
                                                    @foreach ($LeadStatus as $LeadStatusData)
                                                        <option value="{{ $LeadStatusData->name }}"
                                                            {{ collect(old('lead_status'))->contains($LeadStatusData->name) ? 'selected' : '' }}>
                                                            {{ $LeadStatusData->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('lead_status')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Lead Type <span
                                                        class="text-danger">*</span></label>
                                                <select name="lead_type_bifurcation" class="selectpicker"
                                                    data-style="btn-light" id="example-select">

                                                    @foreach ($leadTypeBifurcations as $leadTypeBifurcation)
                                                        <option value="{{ $leadTypeBifurcation->id }}"
                                                            {{ collect(old('lead_type_bifurcation'))->contains($leadTypeBifurcation->id) ? 'selected' : '' }}>
                                                            {{ $leadTypeBifurcation->lead_type_bifurcation }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @error('lead_type_bifurcation')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Number of Units</label>
                                                <select name="number_of_units" class="selectpicker" data-style="btn-light"
                                                    id="example-select" placeholder="Select Lead Status" selected>
                                                    @foreach ($number_of_units as $number_of_unit)
                                                        <option value="{{ $number_of_unit->number_of_units . ' unit' }}"
                                                            {{ collect(old('number_of_units'))->contains($number_of_unit->number_of_units . ' unit') ? 'selected' : '' }}>
                                                            {{ $number_of_unit->number_of_units . ' unit' }}</option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Customer Type</label>
                                                <select name="property_requirement" class="selectpicker"
                                                    data-style="btn-light" id="example-select"
                                                    placeholder="Select Lead Status" onchange="yesnoCheck(this);">
                                                    @foreach ($buyerSellers as $buyerSeller)
                                                        <option value="{{ $buyerSeller->id }}"
                                                            {{ collect(old('property_requirement'))->contains($buyerSeller->name) ? 'selected' : '' }}>
                                                            {{ $buyerSeller->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3" id="rentBudget" style="display: none;">
                                                <label for="simpleinput">Rent Budget</label>
                                                <input type="text" name="rent" class="form-control"
                                                    value="{{ old('lead_name') }}">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Customer Interaction</label>
                                                <textarea class="form-control" name="customer_interaction" id="exampleFormControlTextarea1" rows="2">{{ old('customer_interaction') }}</textarea>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Customer Profile</label>
                                                <textarea class="form-control" name="about_customer" id="exampleFormControlTextarea1" rows="2">{{ old('about_customer') }}</textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button name="submit" value="submit" type="submit"
                                        class="btn btn-primary waves-effect waves-light">Add
                                        Lead</button>

                            </div>

                            </form>
                        </div>
                    </div>
                </div> <!-- end card-body-->

            </div> <!-- end card-->


        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection




@section('scripts')
    <script>
        function yesnoCheck(that) {
            // alert("Hello");
            if (that.value == "4" || that.value == "5") {
                document.getElementById("rentBudget").style.display = "block";
            } else {
                document.getElementById("rentBudget").style.display = "none";
            }


        }
    </script>
@endsection

{{-- @section('scripts') --}}
{{-- <script>
        //Add Input Fields
        $(document).ready(function() {
            var max_fields = 10; //Maximum allowed input fields 
            var wrapper = $(".wrapper"); //Input fields wrapper
            var add_button = $(".add_fields"); //Add button class or ID
            var x = 1; //Initial input field is set to 1

            //- Using an anonymous function:
            // document.getElementById("Array_name").onclick = function () { alert('hello!'); };

            //When user click on add input button
            $(add_button).click(function(e) {
                e.preventDefault();
                //Check maximum allowed input fields
                if (x < max_fields) {
                    x++; //input field increment
                    //add input field
                    $(wrapper).append(
                        '<div><label for="simpleinput">Customer Name </label> <span class="fa fa-minus remove_field" style="cursor: pointer"></span><input type="text" class="form-control" name="lead_name[]"/></div>'
                        );

                    if (x == 10) {
                        alert("Only Used 10 Filed");
                    }
                }
            });

            //when user click on remove button
            $(wrapper).on("click", ".remove_field", function(e) {
                e.preventDefault();
                $(this).parent('div').remove(); //remove inout field
                x--; //inout field decrement
            })
        });

        $(document).ready(function() {
            var max_fields1 = 10; //Maximum allowed input fields 
            var wrapper1 = $(".wrapper1"); //Input fields wrapper
            var add_button1 = $(".add_fields1"); //Add button class or ID
            var x1 = 1; //Initial input field is set to 1

            //- Using an anonymous function:
            // document.getElementById("Array_name").onclick = function () { alert('hello!'); };

            //When user click on add input button
            $(add_button1).click(function(e) {
                e.preventDefault();
                //Check maximum allowed input fields
                if (x1 < max_fields1) {
                    x1++; //input field increment
                    //add input field
                    $(wrapper1).append(
                        '<div><label for="simpleinput">Contact Number </label> <span class="fa fa-minus minus remove_field1" style="cursor: pointer"></span><input type="text" class="form-control" name="contact_number[]"/></div>'
                        );

                    if (x1 == 10) {
                        alert("Only Used 10 Filed");
                    }
                }
            });

            //when user click on remove button
            $(wrapper1).on("click", ".remove_field1", function(e) {
                e.preventDefault();
                $(this).parent('div').remove(); //remove inout field
                x1--; //inout field decrement
            })
        });
 
    </script> --}}


{{-- @endsection --}}
