@extends('main')


@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Lead</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Update Leads</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                @if (session()->has('success'))
                                    <div class="alert alert-success text-center">
                                        {{ session()->get('success') }} </div>
                                @endif
                                <form method="post" action="{{ route('update-lead', $leads->id) }}">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Lead Generation Date</label>
                                                <input type="datetime-local" name="date" id="" class="form-control date"
                                                    value="@php  echo date('Y-m-d\TH:i:s',strtotime($leads->date)) @endphp">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Name of Customer</label>
                                                <input type="text" name="lead_name" class="form-control"
                                                    value="{{ $leads->lead_name }}">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Email</label>
                                                <input type="email" name="lead_email" class="form-control"
                                                    value="{{ $leads->lead_email }}">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Contact Number <span
                                                    class="text-danger">*</span></label>
                                                <input type="text" name="contact_number" class="form-control"
                                                    value="{{ $leads->contact_number }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" >
                                                @error('contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Alt Contact Number 1 </label>
                                                <input type="text" name="alt_contact_number_1" class="form-control"
                                                    value="{{ $leads->alt_no_Whatsapp }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" >
                                                @error('alt_contact_number_1')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Alt Contact Number 2</label>
                                                <input type="text" name="alt_contact_number_2" class="form-control"
                                                    value="{{ $leads->alt_no_Whatsapp_2 }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('alt_contact_number_2')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Customer Requirement</label>
                                                <select name="project_type[]" class="selectpicker" data-style="btn-light"
                                                    multiple>
                                                    @php
                                                        $selected = explode(',', $leads->project_type);
                                                    @endphp
                                                    <option>Select Customer Requirement</option>
                                                    @foreach ($projectTypes as $projectType)
                                                        <option value="{{ $projectType->project_type }}"
                                                            {{ in_array($projectType->project_type, $selected) ? 'selected' : '' }}>
                                                            {{ $projectType->project_type }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Project</label>
                                                <select name="project" class="selectpicker" data-style="btn-light">
                                                    <option>Select Project</option>
                                                    @foreach ($projects as $project)
                                                        @if ($project->id == $leads->project_id)
                                                            <option value="{{ $project->id }}" selected>
                                                                {{ $project->project_name }}</option>
                                                        @else
                                                            <option value="{{ $project->id }}">
                                                                {{ $project->project_name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        {{-- <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Preference Type</label>
                                                <select name="preference" class="selectpicker" data-style="btn-light">
                                                    <option>Select Preference Type</option>

                                                      @foreach ($preferences as $preference)
                                                         @if ($preference->preference == $leads->preference)
                                                            <option value="{{ $leads->preference }}" selected>
                                                                {{ $leads->preference }}</option>
                                                          @else
                                                        <option value="{{ $preference->preference }}">
                                                            {{ $preference->preference }}</option>
                                                          @endif
                                                      @endforeach
                                                </select>
                                            </div>
                                        </div> --}}
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Location</label>
                                                <select name="location_of_leads" class="selectpicker"
                                                    data-style="btn-light" id="example-select">
                                                    <option selected="">Select Assign Location</option>
                                                    @foreach ($locations as $location)
                                                        @if ($location->id == $leads->location_of_leads)
                                                            <option value="{{ $location->id }}" selected>
                                                                {{ $location->location }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $location->id }}">
                                                                {{ $location->location }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Mode of Lead</label>
                                                <select name="source" class="selectpicker" data-style="btn-light"
                                                    id="example-select">
                                                    <option selected="">Select Source Types</option>
                                                    @foreach ($SourceTypes as $SourceType)
                                                        @if ($SourceType->source_types == $leads->source)
                                                            <option value="{{ $SourceType->source_types }}" selected>
                                                                {{ $SourceType->source_types }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $SourceType->source_types }}">
                                                                {{ $SourceType->source_types }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Assign Employees</label>
                                                <select name="assign_employee_id" class="selectpicker"
                                                    data-style="btn-light" id="example-select">
                                                    <option selected="">Select Assign Employees</option>
                                                    @foreach ($employees as $employee)
                                                        @if ($employee->id == $leads->assign_employee_id)
                                                            <option value="{{ $employee->id }}" selected>
                                                                {{ $employee->employee_name }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $employee->id }}">
                                                                {{ $employee->employee_name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Lead Status</label>
                                                <select name="lead_status" class="selectpicker" data-style="btn-light"
                                                    id="example-select" placeholder="Select Lead Status" selected>

                                                    @foreach ($LeadStatus as $LeadStatusData)
                                                        @if ($LeadStatusData->name == $leads->lead_status)
                                                            <option value="{{ $LeadStatusData->name }}" selected>
                                                                {{ $LeadStatusData->name }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $LeadStatusData->name }}">
                                                                {{ $LeadStatusData->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">

                                                <label for="example-select">Lead Type <span
                                                        class="text-danger">*</span></label>
                                                <select name="lead_type_bifurcation" class="selectpicker"
                                                    data-style="btn-light" id="example-select">
                                                    {{-- <option selected="">Select Lead Status</option> --}}
                                                    @foreach ($LeadTypes as $LeadType)
                                                        @if ($LeadType->id == $leads->lead_type_bifurcation_id)
                                                            <option value="{{ $LeadType->id }}" selected>
                                                                {{ $LeadType->lead_type_bifurcation }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $LeadType->id }}">
                                                                {{ $LeadType->lead_type_bifurcation }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Number of Units</label>
                                                <select name="number_of_units" class="selectpicker" data-style="btn-light"
                                                    id="example-select" placeholder="Select Lead Status" selected>
                                                    @foreach ($number_of_units as $number_of_unit)
                                                        @if ($number_of_unit->number_of_units == $leads->number_of_units)
                                                            <option
                                                                value="{{ $number_of_unit->number_of_units . ' unit' }}"
                                                                selected>
                                                                {{ $number_of_unit->number_of_units . ' unit' }}</option>
                                                        @else
                                                            <option
                                                                value="{{ $number_of_unit->number_of_units . ' unit' }}">
                                                                {{ $number_of_unit->number_of_units . ' unit' }}</option>
                                                        @endif
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Reference Name</label>
                                                <input type="text" name="reference" class="form-control"
                                                    value="{{ $leads->reference }}">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Reference Contact Number</label>
                                                <input type="text" name="reference_contact_number" class="form-control"
                                                    value="{{ $leads->reference_contact_number }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" >
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Investment or End User</label>

                                                <select name="investment_or_end_user" class="selectpicker"
                                                    data-style="btn-light" id="example-select"
                                                    placeholder="Select Lead Status" selected>

                                                    {{-- @if ($leads->investment_or_end_user == 'Investment') --}}
                                                    <option value="Investment">Investment</option>
                                                    {{-- @elseif($leads->investment_or_end_user ==" End User") --}}
                                                    <option value="End User">End User</option>
                                                    {{-- @elseif($leads->investment_or_end_user =="Both") --}}
                                                    <option value="Both">Both</option>
                                                    {{-- @else --}}

                                                    {{-- @endif
                                                    @endforeach --}}
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Budget</label>
                                                <select name="budget" id="" class="selectpicker" data-style="btn-light"
                                                    id="example-select" placeholder="Select Lead Status">
                                                    @foreach ($Budgets as $Budget)
                                                        @if ($Budget->budget == $leads->budget)
                                                            <Option name="buget" value="{{ $Budget->budget }}" selected>
                                                                {{ $Budget->budget }}</Option>
                                                        @else
                                                            <Option name="buget" value="{{ $Budget->budget }}">
                                                                {{ $Budget->budget }}</Option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>

                                            
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Location of Customer</label>
                                                <input type="text" name="location_of_client" class="form-control"
                                                    value="{{ $leads->location_of_client }}">
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Customer Type</label>
                                                <select name="buyer_seller" class="selectpicker" data-style="btn-light"
                                                    id="customerType" onchange="yesnoCheck(this);"
                                                    placeholder="Select Lead Status" selected>
                                                    @foreach ($buyerSellers as $buyerSeller)
                                                        @if ($buyerSeller->id == $leads->buyer_seller)
                                                            <option value="{{ $buyerSeller->id }}" selected>
                                                                {{ $buyerSeller->name }}</option>
                                                        @else
                                                            <option value="{{ $buyerSeller->id }}">
                                                                {{ $buyerSeller->name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            @if ($leads->rent)
                                            <div class="form-group mb-3" id="rentBudget">
                                                <label for="simpleinput">Rent Budget</label>
                                                <input type="text" name="rent" class="form-control"
                                                    value="{{ $leads->rent }}">
                                            </div>
                                            @else
                                            <div class="form-group mb-3" id="rentBudget" style="display: none;">
                                                <label for="simpleinput">Rent Budget</label>
                                                <input type="text" name="rent" id="test"  class="form-control"
                                                value="{{ null }}">
                                            </div>
                                            @endif
                                            
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_number">
                                                    Relative Contact Number
                                                </label>

                                                <input type="text" name="emergeny_contact_number" class="form-control"
                                                    onchange="myChangeFunction(this)" id="RelationContactNumber" value="{{ $leads->emergeny_contact_number }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" >
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_name">
                                                    Relative Contact Name
                                                </label>
                                                {{-- <input type="text" id="RelationContactNumber1" name="emergeny_contact_name"
                                                    class="form-control" value="{{ $ab = old('contact_number') }}"> --}}



                                               <select name="leadnames" class="form-control" id="example-select">
                                                    <option>Select</option>
                                                    @foreach ($leadnames as $lead)
                                                        @if ($lead->id == $leads->emergeny_contact_name)
                                                            <option value="{{ $lead->id }}" selected>
                                                                {{ $lead->lead_name }}</option>
                                                        @else
                                                            <option value="{{ $lead->id }}">{{ $lead->lead_name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                @error('emergeny_contact_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>



                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Relationship</label>
                                                <select name="relationship" class="form-control" id="example-select">
                                                    <option>Select</option>
                                                    @foreach ($relations as $relation)
                                                        @if ($relation->name == $leads->relationship)
                                                            <option value="{{ $relation->name }}" selected>
                                                                {{ $relation->name }}</option>
                                                        @else
                                                            <option value="{{ $relation->name }}">
                                                                {{ $relation->name }}</option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>



                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Booking Date</label>
                                                <input type="date" name="booking_date" class="form-control"
                                                    value="{{ $leads->booking_Date }}">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Booking Amount</label>
                                                <input type="text" name="booking_amount" class="form-control"
                                                    value="{{ $leads->booking_amount }}">
                                            </div>
                                        </div>

                                        <div class="col-md-4">

                                            @php
                                                $selected = explode(',', $leads->booking_project);
                                            @endphp

                                            <div class="form-group mb-3">
                                                <label for="example-select">Booking Project</label>
                                                <select name="booking_project[]" class="selectpicker"
                                                    data-style="btn-light" multiple>
                                                    <option>Select Project</option>
                                                    @foreach ($projects as $project)
                                                        <option value="{{ $project->id }}"
                                                            {{ in_array($project->id, $selected) ? 'selected' : '' }}>
                                                            {{ $project->project_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>



                                        <div class="checkbox checkbox-success checkbox-circle mb-2 ml-2">
                                            <input id="checkbox-2" name="common_pool_status" type="checkbox" value="1"
                                                {{ $leads->common_pool_status == 1 ? 'checked' : '' }}>
                                            <label for="checkbox-2">
                                                Move to Common Pool
                                            </label>
                                        </div>

                                        <div class="checkbox checkbox-success checkbox-circle mb-2 ml-2">
                                            <input id="checkbox-3" name="is_featured" type="checkbox" value="1"
                                                {{ $leads->is_featured == 1 ? 'checked' : '' }}>
                                            <label for="checkbox-3">
                                                Featured
                                            </label>
                                        </div>

                                    </div>

                                    <div class="">
                                        <label for="simpleinput">Regular Investor</label>
                                        <div class="form-group mb-3 d-flex">

                                            <div class="checkbox checkbox-success checkbox-circle mb-2">
                                                <input id="checkbox-4" name="regular_investor" type="checkbox" value="YES"
                                                    {{ $leads->regular_investor == 'YES' ? 'checked' : '' }}>
                                                <label for="checkbox-4">
                                                    Yes
                                                </label>
                                            </div>

                                        </div>
                                    </div>





                                    <button name="submit" value="submit" type="submit"
                                        class="btn btn-primary waves-effect waves-light">Update Leads</button>
                                </form>

                            </div>

                        </div>


                    </div> <!-- end card-body-->

                </div> <!-- end card-->



            </div> <!-- end col -->

        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection

@section('scripts')
    <script>
        function yesnoCheck(that) {

            //  var input2 = document.getElementById('rentBudget');
            //   alert(input2.value);
            //  RelationContactNumber1.value = RelationContactNumber.value;

            if (that.value == "4" || that.value == "5") {
                document.getElementById("rentBudget").style.display = "block";
            } else {
                document.getElementById("rentBudget").style.display = "none";
            
            }
        }

        // function myChangeFunction(input1) {
        //     var input2 = document.getElementById('RelationContactNumber');
        //     // alert(input2.value);
        //     RelationContactNumber1.value = RelationContactNumber.value;

        //     fetch('/lead-number', {
        //         method: 'post',
        //         contact_number: input2,
        //         headers: {
        //             'Content-Type': 'application/json',
        //             'Accept': 'application/json',
        //             'url': '/lead-number',
        //             "X-CSRF-Token": document.querySelector('input[name=_token]').value
        //         },
        //     }).then(function(response) {
        //         console.log(response);
        //     })

        // }
    </script>
@endsection
