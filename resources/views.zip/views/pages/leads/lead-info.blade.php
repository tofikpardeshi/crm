@extends('main')

@section('dynamic_page')
    <div class="row">
        <div class="col-lg-12 my-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12 d-flex justify-content-end">
                            <a type="button" class="btn btn-danger waves-effect waves-light  mr-1"
                                href="{{ url('lead-stutas-update/' . $leads->id) }}">Update Statut</a>

                            <a type="button" class="btn btn-danger waves-effect waves-light  mr-1"
                                href="{{ url('edit-leads/' . $leads->id) }}">Edit</a>

                            <a type="button" class="btn btn-danger waves-effect waves-light  "
                                href="{{ route('leads-index') }}">Back</a>
                        </div><!-- end col-->


                    </div>
                    <h2 class="page-title mt-3 ml-1">Leads Information</h2>
                    <hr>
                    <div class="container">
                        @php
                            $location = App\Models\Location::where('id', $leads->location_of_leads)
                                ->select('location')
                                ->first();
                            
                            $LeadType = DB::table('lead_type_bifurcation')
                                ->where('id', $leads->lead_type_bifurcation_id)
                                ->select('lead_type_bifurcation')
                                ->first();
                            
                            $Units = DB::table('number_of_units')
                                ->where('id', $leads->number_of_units)
                                ->select('number_of_units')
                                ->first();
                            
                            $Project = App\Models\Project::where('id', $leads->project_id)
                                ->select('project_name')
                                ->first();
                            
                            $emergeny_name = App\Models\Lead::where('id', $leads->emergeny_contact_name)
                                ->select('lead_name')
                                ->first();
                            
                            $Customer_type = DB::table('buyer_sellers')
                                ->where('id', $leads->buyer_seller)
                                ->select('name')
                                ->first();
                            
                        @endphp

                        <div class="row d-flex justify-content-between mx-auto">
                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Name: <strong>{{ $leads->lead_name }}</strong></div>
                                <div class="my-2">Email: <strong>{{ $leads->lead_email }}</strong></div>
                                <div class="my-2">Mode of Lead: <strong>{{ $leads->source }}</strong></div>
                            </div>

                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Date: <strong>
                                        {{ \Carbon\Carbon::parse($leads->date)->format('j-F-Y H:i') }} </strong></div>
                                <div class="my-2">Lead Status: <strong>{{ $leads->lead_status }}</strong></div>
                                <div class="my-2">Assigned To: <strong>{{ $leads->employee_name }}</strong>
                                </div>
                            </div>

                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Contact Number: <strong>{{ $leads->contact_number }} </strong>
                                </div>
                                <div class="my-2">Customer Requirement:
                                    <strong>{{ $leads->project_type }}</strong>
                                </div>
                                @if ($leads->project_id == 0)
                                    <div class="my-2">Project: <strong>{{ 'Null' }}</strong>
                                    @else
                                        <div class="my-2">Project:
                                            <strong>{{ $Project->project_name }}</strong>
                                @endif

                            </div>
                        </div>

                        <div class="col-md-3 d-flex flex-column">
                            <div class="my-2">Location: <strong>{{ $location->location }}</strong></div>
                            <div class="my-2">Lead Type:
                                <strong>{{ $LeadType->lead_type_bifurcation }}</strong>
                            </div>
                            <div class="my-2">Number of Units:
                                <strong>{{ $Units->number_of_units . ' Unit' }}</strong>
                            </div>
                        </div>

                        <button class="btn btn-info ml-auto" id="showMore"> Show More </button>
                    </div>


                    {{-- More Lead Detaile Section --}}
                    <div id="rentBudget" style="display: none;">
                        <div class="row  mx-auto d-flex">


                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Reference Name: <strong>{{ $leads->reference }}</strong>
                                </div>
                                <div class="my-2">Reference Contact Number:
                                    <strong>{{ $leads->reference_contact_number }}</strong>
                                </div>
                                <div class="my-2">Investment or End User:
                                    <strong>{{ $leads->investment_or_end_user }}</strong>
                                </div>
                                @if ($leads->is_featured == 0)
                                    <div class="my-2">Featured: <strong>{{ 'NO' }}</strong></div>
                                @else
                                    <div class="my-2">Featured: <strong>{{ 'YES' }}</strong></div>
                                @endif
                            </div>

                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Budget: <strong>{{ $leads->budget }} </strong></div>
                                <div class="my-2">Location of Customer:
                                    <strong>{{ $leads->location_of_client }}</strong>
                                </div>
                                @if ($Customer_type == null)
                                    <div class="my-2">Customer Type: <strong>{{ 'Null' }}</strong>

                                    </div>
                                @else
                                    <div class="my-2">Customer Type:
                                        <strong>{{ $Customer_type->name }}</strong>

                                    </div>
                                @endif
                                @if ($leads->regular_investor == null)
                                    <div class="my-2">Regular Investor: <strong>{{ 'NO' }}</strong>
                                    </div>
                                @else
                                    <div class="my-2">Regular Investor:
                                        <strong>{{ $leads->regular_investor }}</strong>
                                    </div>
                                @endif

                            </div>

                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Rent Budget: <strong>{{ $leads->rent }} </strong></div>
                                <div class="my-2">Relationship: <strong>{{ $leads->relationship }}</strong>
                                </div>

                                @if ($emergeny_name == null)
                                    <div class="my-2">Emergency Contact Name:
                                        <strong>{{ 'Null' }}</strong>
                                    </div>
                                @else
                                    <div class="my-2">Emergency Contact Name:
                                        <strong>{{ $emergeny_name->lead_name }}</strong>
                                    </div>
                                @endif

                                <div class="my-2">Customer Profile: 
                                    
                                    {{ \Illuminate\Support\Str::limit(strip_tags($leads->about_customer), 20) }}
                                        <br>
                                        @if (strlen(strip_tags($leads->about_customer)) > 20)
                                            <button class='text-white aboutcustomer btn btn-info btn-sm'
                                                style="cursor:pointer" data-toggle="modal" data-target="#exampleModalCenter1"
                                                value="{{ $leads->about_customer }}">
                                                Read More
                                            </button>
                                        @endif

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle">Customer
                                                            Profile</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        {{ Form::textarea('comment',$leads->about_customer, 
                                                        ['id' => 'about_customer', 'class' => 'form-control', 'rows' => '5', 'readonly' => 'true']) }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                
                                </div>
                            </div>

                            <div class="col-md-3 d-flex flex-column">
                                <div class="my-2">Emergency Contact Number: <strong>
                                        {{ $leads->emergeny_contact_number }} </strong></div>
                                <div class="my-2">Booking Date: <strong>{{ $leads->booking_Date }}</strong>
                                </div>
                                <div class="my-2">Booking Amount: <strong>{{ $leads->booking_amount }}</strong>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <h2 class="page-title mt-3 ml-1">Status History</h2>
                {{-- <hr> --}}
                <div class="container">
                    <table class="table table-centered table-nowrap table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Lead Status</th>
                                <th>Next Follow Up Date</th>
                                <th>Project Visit</th>
                                <th>Updated By</th>
                                <th>Customer Interaction</th>
                                {{-- <th>Customer Profile</th> --}}
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($leadstatushistory as $leadstatus)
                                <tr>

                                    <td>
                                        {{ \Carbon\Carbon::parse($leadstatus->date)->format('j-F-Y H:i') }}
                                    </td>
                                    {{-- <td>
                                            {{ $leadstatus->follow_up_time }}
                                        </td> --}}
                                    <td>
                                        {{ $leadstatus->status_id }}
                                    </td>
                                    @if ($leadstatus->next_follow_up_date == null)
                                        <td></td>
                                    @else
                                        <td>
                                            @if (\Carbon\Carbon::now()->diffInSeconds($leadstatus->next_follow_up_date, false) > 0)
                                                {{-- <div class="text-info"> --}}
                                                {{ \Carbon\Carbon::parse($leadstatus->next_follow_up_date)->format('j-F-Y H:i') }}
                                                {{-- </div> --}}
                                            @else
                                                <div class="text-danger">
                                                    {{ \Carbon\Carbon::parse($leadstatus->next_follow_up_date)->format('j-F-Y H:i') }}
                                                </div>
                                            @endif

                                        </td>
                                    @endif

                                    @php
                                        $projects = DB::table('projects')->get();
                                        $selected = explode(',', $leadstatus->project_id);
                                        $test = '';
                                    @endphp

                                    <td>


                                        @foreach ($projects as $project)
                                            {{-- @php  
                                                $test = '| ';
                                            @endphp --}}

                                            {{ in_array($project->id, $selected) ? $project->project_name . ',' : '' }}
                                        @endforeach
                                    </td>



                                    @php
                                        $updatedBY = DB::table('users')
                                            ->where('id', $leadstatus->created_by)
                                            ->first();
                                    @endphp
                                    @if($updatedBY == null)

                                    <td></td>
                                    @else
                                    
                                    <td>{{ $updatedBY->name }}</td>

                                    @endif
                                    

                                    <td>
                                        {{-- {{ \Illuminate\Support\Str::limit(, 20, $end = '...') }} --}}
                                        {{ \Illuminate\Support\Str::limit(strip_tags($leadstatus->customer_interaction), 20) }}
                                        <br>
                                        @if (strlen(strip_tags($leadstatus->customer_interaction)) > 20)
                                            <button class='text-white updateStatus btn btn-info btn-sm'
                                                style="cursor:pointer" data-toggle="modal" data-target="#exampleModalCenter"
                                                value="{{ $leadstatus->customer_interaction }}">
                                                Read More
                                            </button>
                                        @endif

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle">Customer
                                                            Interaction</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        {{ Form::textarea('comment', $leadstatus->customer_interaction, ['id' => 'lead_id', 'class' => 'form-control', 'rows' => '5', 'readonly' => 'true']) }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>  
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                        {{ $leadstatushistory->links('pagination::bootstrap-4') }}
                    </ul>
                </div>

            </div> <!-- end card-body-->

            {{-- {{ $leadstatushistory->links(); }} --}}

        </div> <!-- end card-->
    </div> <!-- end col -->


    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            $("#showMore").click(function() {
                // alert("helo");
                $("#rentBudget").toggle();
            });
        });

        //  modal in latavel 
        $(document).ready(function() {
            $(document).on('click', '.updateStatus', function() {
                var lead_id = $(this).val();
                $('#lead_id').val(lead_id)
                $('#exampleModalCenter').modal('show');
            })
        });

        $(document).ready(function() {
            $(document).on('click', '.aboutcustomer', function() {
                var lead_ids = $(this).val();
                $('#about_customer').val(lead_ids)
                $('#exampleModalCenter1').modal('show');
            })
        })
        //  modal in latavel End
    </script>
@endsection
