@extends('main')


@section('dynamic_page')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Employees</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Create Employee</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-end">
                            <a type="button" class="btn btn-danger waves-effect waves-light  "
                                href="{{ url('employees') }}">Back</a>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible">
                                        <h5>{{ Session::get('success') }}</h5>
                                    </div>
                                @endif
                                <form action="{{ route('create-employee') }}" enctype="multipart/form-data" method="post">
                                    @csrf


                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="control-label" for="simpleinput">Employee ID<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="employeeID" class="form-control" autocomplete="off" value={{old('employeeID')}}>
                                                @error('employeeID')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="control-label" for="simpleinput">Name <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="employee_name" class="form-control" autocomplete="off" value={{old('employee_name')}}>
                                                @error('employee_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Email <span
                                                        class="text-danger">*</span></label>
                                                <input type="email" name="email" id="example-email" name="example-email"
                                                    class="form-control" placeholder="Email" autocomplete="off" value={{old('email')}}>
                                                @error('email')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Official Email<span
                                                        class="text-danger">*</span></label>
                                                <input type="email" 
                                                    name="official_email" 
                                                    id="example-email"
                                                    name="example-email" 
                                                    class="form-control" 
                                                    placeholder="Email"
                                                    autocomplete="off" 
                                                    value={{old('official_email')}}>
                                                @error('official_email')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div> 

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Password <span
                                                        class="text-danger">*</span></label>
                                                <input type="password" name="password" id="example-password"
                                                    class="form-control" value={{old('password')}}>
                                                @error('password')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="password">Confirm Password <span
                                                        class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="password" name="confirm_password" id="password"
                                                        class="form-control" placeholder="Enter your password" value={{old('confirm_password')}}>
                                                    <div class="input-group-append" data-password="false">
                                                        <div class="input-group-text">
                                                            <span class="password-eye"></span>
                                                        </div>
                                                    </div> 
                                                </div>
                                                @error('confirm_password')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Role <span
                                                        class="text-danger">*</span></label>
                                                <select name="role_id" class="form-control" id="example-select">
                                                    @foreach ($roles as $role)
                                                        <option value="{{ $role->id }}" 
                                                            {{ (collect(old('role_id'))->contains($role->id)) ? 'selected':'' }}>
                                                            {{ $role->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Personal Phone Number <span
                                                    class="text-danger">*</span></label>
                                                <input type="text" name="personal_phone_number"
                                                    class="form-control" value="{{old('personal_phone_number')}}" 
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('personal_phone_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Official Phone Number <span
                                                    class="text-danger">*</span></label>
                                                <input type="text" name="official_phone_number"
                                                    class="form-control" value="{{old('official_phone_number')}}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('official_phone_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Department</label>
                                                <input type="text" name="department"  
                                                    class="form-control" value={{old('department')}}>
                                                @error('department')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Aadhar Number</label>
                                                <input type="text" name="addhar_number" id="addhar_number"
                                                    class="form-control" value={{old('addhar_number')}}>

                                                @error('addhar_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div> 
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="pan-number">PAN Number</label>
                                                <input type="text" name="pan_Number" class="form-control" value={{old('pan_Number')}}>
                                                @error('pan_Number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Date Of Joining</label>
                                                <input type="date" name="date_joining"  
                                                class="form-control"
                                                 value={{old('date_joining')}}>
                                                @error('date_joining')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                             
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Relieving date
                                                </label>
                                                <input type="date" 
                                                name="leaving_date" 
                                                class="form-control"  
                                                value={{old('leaving_date')}}>
                                                @error('leaving_date')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            @php
                                                $DOB = Carbon\Carbon::now();
                                            @endphp
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Date of Brith<span
                                                    class="text-danger"> *</span></label>
                                                <input type="date" name="date_of_brith"  
                                                 class="form-control"
                                                 value={{old('date_of_brith')}}>
                                                @error('date_of_brith')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Marriage Anniversary <span
                                                    class="text-danger"> *</span></label>
                                                <input type="date" name="marriage_anniversary" class="form-control"
                                                value={{old('marriage_anniversary')}}>
                                                @error('marriage_anniversary')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div> 

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Current Address</label>
                                                <input type="text" name="current_address" id="address" class="form-control"
                                                value={{old('current_address')}}>

                                                @error('address')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Permanent Address</label>
                                                <input type="text" name="permanent_address" id="address"
                                                    class="form-control" value={{old('permanent_address')}}>

                                                @error('address')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Education Background</label>
                                                <input type="text" name="education_background" class="form-control"
                                                value={{old('education_background')}}>
                                                @error('education_background')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Blood Group<span
                                                        class="text-danger">*</span></label>
                                                <select name="blood_group" class="form-control" id="example-select">
                                                    @foreach ($bloobgroups as $bloobgroup)
                                                    <option value="{{ $bloobgroup->name }}"
                                                        {{ (collect(old('blood_group'))->contains($bloobgroup->name)) ? 'selected':'' }}>
                                                       {{ $bloobgroup->name }}
                                                    </option> 
                                                    @endforeach 
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Location<span
                                                        class="text-danger">*</span></label>
                                                <select name="employee_location" class="form-control" id="example-select">
                                                    @foreach ($locations as $location)
                                                        <option value="{{ $location->location }}"  {{ (collect(old('employee_location'))->contains($location->location)) ? 'selected':'' }}>
                                                            {{ $location->location }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_name">Emergency Contact Name</label>
                                                <input type="text" name="emergeny_contact_name" class="form-control"
                                                value="{{old('emergeny_contact_name')}}">
                                                @error('emergeny_contact_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_name">Emergency Contact Number</label>
                                                <input type="text" name="emergeny_contact_number" class="form-control"
                                                value="{{old('emergeny_contact_name')}}"
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('emergeny_contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Relationship</label>
                                                <select name="relationship" class="form-control" id="example-select">
                                                    <option>Select</option>  
                                                    @foreach ($relations as $relation)
                                                     <option  value="{{ $relation->name }}"
                                                        {{ (collect(old('relationship'))->contains($relation->name)) ? 'selected':'' }}>{{ $relation->name }}</option> 
                                                    @endforeach
                                                    
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="col-lg-4">
                                            <div class="dropzone-previews" id="file-previews"></div>

                                            <div class="fallback">
                                                <input class="form-control" name="photo" type="file" />
                                            </div>
                                        </div> 
                                    </div>

                                    <div class="col-lg-6 mt-3"> 
                                        <div class="checkbox checkbox-success checkbox-circle mb-2"> 
                                            <input id="checkbox-2" name="lead_assignment" type="checkbox" value="1"
                                            {{ old('lead_assignment') == '1' ? 'checked' : '' }}>
                                            <label for="checkbox-2">
                                                Lead Assignment
                                            </label> 
                                        </div> 
                                    </div>


                                    <button name="submit" type="submit" class=" mt-2 btn btn-primary" value="submit">Add
                                        Now</button>

                                </form>
                            </div>




                        </div>


                    </div> <!-- end card-body-->

                </div> <!-- end card-->
                <div class="row">
                    <div class="col-12">
                    </div>
                </div>


            </div> <!-- end col -->

        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection
