@extends('main')


@section('dynamic_page')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Employees</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Edit Employee</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                
                <div class="card">
                    
                    <div class="card-body">
                        <div class="d-flex justify-content-end">
                            <a type="button" class="btn btn-danger waves-effect waves-light  "
                                href="{{ url('employees') }}">Back</a>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible">
                                        <h5>{{ Session::get('success') }}</h5>
                                    </div>
                                @endif
                                <form action="{{ route('update-employee', $employee->id) }}" enctype="multipart/form-data"
                                    method="post">
                                    @csrf


                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="control-label" for="simpleinput">Employee ID<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" value="{{ $employee->employeeID }}" name="employeeID"
                                                    class="form-control" autocomplete="off" required>
                                                @error('employeeID')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="control-label" for="simpleinput">Name <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="employee_name" class="form-control"
                                                    value="{{ $employee->employee_name }}" autocomplete="off" required>
                                                @error('employee_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Email <span
                                                        class="text-danger">*</span></label>
                                                <input type="email" value="{{ $employee->email }}" name="email"
                                                    id="example-email" name="example-email" class="form-control"
                                                    placeholder="Email" autocomplete="off" required>
                                                @error('email')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Official Email<span
                                                        class="text-danger">*</span></label>
                                                <input type="email" value="{{ $employee->official_email }}"
                                                    name="official_email" id="example-email" name="example-email"
                                                    class="form-control" placeholder="Email" autocomplete="off" required>
                                                @error('official_email')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>



                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Role <span
                                                        class="text-danger">*</span></label>
                                                <select name="role_id" class="form-control" id="example-select" required>
                                                    @foreach ($roles as $role)
                                                        @if ($role->id == $employee->role_id)
                                                            <option value="{{ $role->id }}" selected>
                                                                {{ $role->name }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $role->id }}">
                                                                {{ $role->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Personal Phone Number 
                                                    {{-- <span class="text-danger">*</span> --}}
                                                </label>
                                                <input type="text" name="personal_phone_number" class="form-control"
                                                    value="{{ $employee->personal_phone_number }}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}" maxlength="10">
                                                @error('personal_phone_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Official Phone Number 
                                                    {{-- <span class="text-danger">*</span> --}}
                                                </label>
                                                <input type="text" name="official_phone_number" class="form-control"
                                                    value="{{ $employee->official_phone_number }}"
                                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('official_phone_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Phone-Number">Department</label>
                                                <input type="text" name="department" class="form-control"
                                                    value="{{ $employee->department }}">
                                                @error('department')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Aadhar Number</label>
                                                <input type="text" name="addhar_number" id="addhar_number"
                                                    class="form-control" value="{{ $employee->addhar_number }}">

                                                @error('addhar_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="pan-number">PAN Number</label>
                                                <input type="text" name="pan_Number" class="form-control"
                                                    value="{{ $employee->pan_Number }}">
                                                @error('pan_Number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Date Of Joining</label>
                                                <input type="date" name="date_joining" class="form-control"
                                                    value="{{ $employee->date_joining }}">
                                                @error('date_joining')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Leaving Date
                                                </label>
                                                <input type="date" name="leaving_date" class="form-control"
                                                    value="{{ $employee->leaving_date }}">
                                                @error('leaving_date')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Date of Brith</label>
                                                <input type="date" name="date_of_brith" class="form-control"
                                                    value="{{ $employee->date_of_brith }}">
                                                @error('date_of_brith')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Marriage Anniversary</label>
                                                <input type="date" name="marriage_anniversary" class="form-control"
                                                    value="{{ $employee->marriage_anniversary }}">
                                                @error('marriage_anniversary')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div> 

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Current Address</label>
                                                <input type="text" name="current_address" id="address"
                                                    class="form-control" value="{{ $employee->current_address }}">

                                                @error('address')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="example-password">Permanent Address</label>
                                                <input type="text" name="permanent_address" id="address"
                                                    class="form-control" value="{{ $employee->permanent_address }}">

                                                @error('address')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Date of Brith">Education Background</label>
                                                <input type="text" name="education_background" class="form-control"
                                                    value="{{ $employee->education_background }}">
                                                @error('education_background')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Blood Group<span
                                                        class="text-danger">*</span></label>
                                                <select name="blood_group" class="form-control" id="example-select">
                                                    @foreach ($bloobgroups as $bloobgroup)
                                                        @if ($bloobgroup->name == $employee->blood_group)
                                                            <option value="{{ $bloobgroup->name }}" selected>
                                                                {{ $bloobgroup->name }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $bloobgroup->name }}">
                                                                {{ $bloobgroup->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
 

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_name">Emergency Contact Name</label>
                                                <input type="text" name="emergeny_contact_name" class="form-control"
                                                    value="{{ $employee->emergeny_contact_name }}">
                                                @error('emergeny_contact_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="Emergeny_Contact_name">Emergency Contact Number</label>
                                                <input type="text" name="emergeny_contact_number" class="form-control"
                                                value={{ $employee->emergeny_contact_number }}
                                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                @error('emergeny_contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div> 

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Relationship</label>
                                                <select name="relationship" class="form-control" id="example-select">
                                                    @foreach ($relations as $relation)
                                                        @if ($relation->name == $employee->relationship)
                                                            <option class="text-capitalize" value="{{ $relation->name }}" selected>
                                                                {{ $relation->name }}
                                                            </option>
                                                        @else
                                                            <option class="text-capitalize" value="{{ $relation->name }}">
                                                                {{ $relation->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-select">Location<span
                                                        class="text-danger">*</span></label>
                                                <select name="employee_location" class="form-control"
                                                    id="example-select">
                                                    @foreach ($locations as $location)
                                                        @if ($location->location == $employee->employee_location)
                                                            <option value="{{ $location->location }}" selected>
                                                                {{ $location->location }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $location->location }}">
                                                                {{ $location->location }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <label for="example-select">Choose Image</label>
                                            <div class="dropzone-previews " id="file-previews"></div>

                                            <div class="fallback">
                                                <input class="form-control" name="photo" type="file" />
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="checkbox checkbox-success checkbox-circle mb-2 mt-4">
                                                <input id="checkbox-2" name="lead_assignment" type="checkbox" value="1"
                                                    {{ $employee->lead_assignment == 1 ? ' checked' : '' }} 
                                                    >
                                                <label for="checkbox-2">
                                                    Lead Assignment
                                                </label>
                                            </div>
                                            
                                        </div>
                                    </div>



                                    <button name="submit" type="submit" class=" mt-2 btn btn-primary"
                                        value="submit">Update</button>

                                </form>
                            </div>




                        </div>


                    </div> <!-- end card-body-->

                </div> <!-- end card-->
                <div class="row">
                    <div class="col-12">
                    </div>
                </div>


            </div> <!-- end col -->

        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection
