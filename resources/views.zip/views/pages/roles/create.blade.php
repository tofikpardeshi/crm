@extends('main')


@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Role</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Create Role</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                    <div class="d-flex justify-content-end">
                                        <a href="{{ route('role-index') }}">
                                        <button class="btn btn-danger">Back</button>
                                        </a>
                                    </div>
                                <form action="{{ route('create-roles') }}" method="POST">
                                    @csrf   
                                    <div class="row">
                                       <div class="col-md-12">
                                       @if (Session::has('success'))
                                        <div class="alert alert-success alert-dismissible">
                                            <h5>{{ Session::get('success') }}</h5>
                                        </div>
                                    @endif
                                    <label for="example-select">Role Name<span class="text-danger">*</span></label>
                                        <input type="text" name="addRole" class="form-control  " placeholder="Add Role">  
                                        @error('addRole')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                        <div class="form-group my-2">
                                            @php
                                            $contactTypes = ['Dashboard', 'Employee', 'Project', 'Leads','Bulk Upload','Common Pool','Roles','Location','Setting'];
                                        @endphp
                                        <label for="example-select">Role Access<span class="text-danger">*</span></label>
                                        <select class="form-control selectpicker" name="permission_tag_name[]" id="example-select" multiple>
                                            @foreach ($contactTypes as $contactType)
                                                <option value="{{ $contactType}}">{{ $contactType }}</option>
                                            @endforeach 
                                        </select>
                                        <label for="example-select ">Permissions</label>
                                        <br>
                                        @foreach($permissions as $permission) 
                                        
                                            <tr>
                                                <td>
                                                    <input type="checkbox" 
                                                    name="permission[{{ $permission->id }}]"
                                                    value="{{ $permission->name }}"
                                                    class='permission mt-2'>  
                                                </td>

                                                <td>{{ $permission->name }}</td>
                                                <br>
                                                
                                            </tr>
                                       
                                        @endforeach 
                                        </div>
                                        @error('permission')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror 
                                    </div> 
                                       </div>
        
                                        <button type="submit" class="btn btn-primary ml-2 my-2">Create</button>
                                    </div>
                                </form> 
                            </div>
                        </div>
                    </div> <!-- end card-body-->
                </div> <!-- end card--> 
            </div> <!-- end card-->
        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection
