@extends('main')


@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Role Details</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Role Details</h4>
                    <div class="table-responsive">
                        @if (Session::has('delete'))
                        <div class="alert alert-danger alert-dismissible">
                            <h5>{{ Session::get('delete') }}</h5>
                        </div>
                    @endif
                        
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row ">
                            <div class="col-12">
                                <table class="table table-centered table-nowrap table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Role Name</th>
                                            <th>Role Access</th>
                                            <th>Premission Name</th>  
                                        </tr>
                                    </thead>
                                    <tbody>
                                         
                                        <tr> 
                                            <td>{{ $roleDetails->name }}</td>
                                                
                                            <td>
                                                @foreach (App\Models\Permission_tag::where('roleID',$roleDetails->id)->select('tag_name')->groupBy('tag_name')->get() as $item)
                                             {{ $item->tag_name }} |
                                             @endforeach  
                                            </td>
        
                                            <td>
                                                @foreach ($permissions as $permission)  
                                                <input class="bg-info"  type="checkbox" name="permission[{{$permission->id}}]"
                                                value="{{ $permission->name }}"
                                                @if($roleDetails->permissions->contains($permission)) checked @else disabled @endif
                                                >  
                                            {{ $permission->name }} 
                                                 @endforeach 
                                              
                                         </td> 
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- end card-body-->
                </div> <!-- end card--> 
            </div> <!-- end card-->
        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection
