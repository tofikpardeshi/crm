@extends('main')


@section('dynamic_page')
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Update Role</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Update Role</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="d-flex justify-content-end">
                                    <a href="{{ route('role-index') }}">
                                    <button class="btn btn-danger">Back</button>
                                    </a>
                                </div>
                                <form action="{{ route('update-role', $role->id) }}" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-12">
                                            @if (Session::has('success'))
                                                <div class="alert alert-success alert-dismissible">
                                                    <h5>{{ Session::get('success') }}</h5>
                                                </div>
                                            @endif
                                            <label for="example-select">Role Name</label>
                                            <input type="text" value="{{ $role->name }}" name="addRole"
                                                class="form-control" placeholder="Add Role">
                                            @error('addRole')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                            <br>
                                            <label for="example-select mt-2">Role Access</label>
                                            <select class="form-control selectpicker" value="{{ $permission_tag }}"
                                                name="permission_tag_name[]" id="example-select" multiple>
                                                @foreach ($data as $dashboard)
                                                    @if ($dashboard['status'] == 1)
                                                        <option value="{{ $dashboard['select'] }}" selected>
                                                            {{ $dashboard['select'] }}
                                                        </option>
                                                    @else
                                                        <option value="{{ $dashboard['select'] }}">
                                                            {{ $dashboard['select'] }}
                                                        </option>
                                                    @endif
                                                @endforeach
                                            </select>
                                            @error('permission_tag_name')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror

                                            <label>Permissions</label>
                                            <div class=" custom-checkbox">
                                                @foreach ($permissions as $permission)
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox"
                                                                name="permission[{{ $permission->id }}]"
                                                                value="{{ $permission->name }}"
                                                                @foreach ($role_has as $s) {{ $permission->id == $s->permission_id ? 'checked' : '' }} @endforeach>

                                                        </td>

                                                        <td>{{ $permission->name }}</td>
                                                        <br>
                                                    </tr>
                                                @endforeach
                                            </div>
                                            @error('permission')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                        </div>

                                        <button type="submit" class="btn btn-primary ml-2 my-2">Update Role</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end card-->
        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection
