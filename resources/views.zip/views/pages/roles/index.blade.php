@extends('main')

 

@section('dynamic_page')
    <!-- Start Content-->
     <!-- Start Content-->
     <div class="container-fluid">
                        
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Homents</a></li>
                            <li class="breadcrumb-item active">Role</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Role</h4>
                </div>
            </div>
        </div>     
        <!-- end page title --> 


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                {{-- <form class="form-inline">
                                    <div class="form-group mb-2">
                                        <label for="inputPassword2" class="sr-only">Search</label>
                                        <input type="search" class="form-control" id="inputPassword2"
                                            placeholder="Search...">
                                    </div>
                                </form> --}}
                            </div>
                            <div class="col-sm-8">
                                <div class="text-sm-right">
                                    {{-- <button type="button" class="btn btn-success waves-effect waves-light mb-2 mr-1"><i
                                            class="mdi mdi-cog"></i></button> --}}
                                    <a type="button" class="btn btn-danger waves-effect waves-light mb-2"
                                        href="{{ route('roles_create') }}">Add Role</a>
                                        
                                </div>
                            </div><!-- end col-->

                            
                        </div>

                        <div class="table-responsive">
                            @if (Session::has('delete'))
                            <div class="alert alert-danger alert-dismissible">
                                <h5>{{ Session::get('delete') }}</h5>
                            </div>
                        @endif
                            <table class="table table-centered table-nowrap table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Role Name</th>
                                        <th>Role Access</th>
                                        <th>Permission</th>
                                        <th>Created Date</th>
                                        <th>Created By</th>
                                        <th>Last Updated Date</th>
                                        <th>Updated By</th>
                                        <th style="width: 82px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($roles as $role) 
                                    <tr> 
                                        <td>{{ $role->name }}</td>
                                            
                                        <td> 
                                            @php
                                                $test ='';
                                            @endphp
                                            @foreach (App\Models\Permission_tag::where('roleID',$role->id)->select('tag_name')->groupBy('tag_name')->get() as $item)
                                            @php
                                                // $test ='';
                                                $demo = $test.$item->tag_name;

                                                $test ='| ';
                                                //  echo($demo);
                                            @endphp
                                            {{ $demo }} 
                                            @endforeach

                                        </td> 

                                        @php
                                            $roleDetails = App\Models\Role::find($role->id);
                                        @endphp
                                        <td>
                                            @foreach ($permissions as $permission)  
                                            <input class="bg-info"  
                                            type="checkbox" 
                                            name="permission[{{$permission->id}}]"
                                            value="{{ $permission->name }}"
                                            onclick="return false;"
                                            @if($roleDetails->permissions->contains($permission)) checked  @else disabled @endif
                                            >  
                                        {{ $permission->name }} 
                                             @endforeach 
                                          
                                     </td> 

                                        <td>{{ $role->created_at }}</td>

                                        @php
                                            $createBYName = DB::table('users')
                                            ->where('id',$role->created_by)->first();

                                            $updatedBYName = DB::table('users')
                                            ->where('id',$role->updated_by)->first();
                                            
                                        @endphp

                                        @if ($createBYName == null)
                                        <td></td>
                                        @else
                                        <td>{{ $createBYName->name }}</td>
                                        @endif

                                        

                                        <td>{{ $role->updated_at }}</td>

                                        @if ($updatedBYName ==  null)
                                        <td></td>
                                        @else
                                        <td>{{ $updatedBYName->name }}</td>
                                        @endif
                                        
                                        
                                        <td>
                                            <a href="{{ url('role-details/'.$role->id) }}"> 
                                                <button 
                                                 class=" waves-effect waves-light   font-weight-semibold btn btn-primary text-white"
                                                 data-toggle="modal" data-target="#custom-modal">Details
                                                </button>
                                            </a>
                                            
                                            <a href="{{ url('edit-role/'.$role->id) }}" class="action-icon"> <i
                                                    class="mdi mdi-square-edit-outline text-info"></i></a>
                                            <a href="{{ url('role-delete/'.$role->id) }}"
                                                
                                                class="action-icon"> <i
                                                    class="mdi mdi-delete text-danger"></i></a>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            
                        </div>

                        <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                            {{ $roles->links('pagination::bootstrap-4'); }}
                        </ul>
                    </div> <!-- end card-body-->
                    
                </div> <!-- end card-->
            </div> <!-- end col -->

            
        </div>
        <!-- end row -->
        
    </div> <!-- container -->
@endsection
