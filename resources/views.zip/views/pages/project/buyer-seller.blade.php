@extends('main')


@section('dynamic_page')
    <!-- Start Content-->
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                       
                    </div>
                    <h4 class="page-title">{{ $buyersellername }}</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                           <div class="col-lg-8">
                                {{-- <form class="form-inline" method="get" action="{{ url('search-lead') }}">
                                    <div class="form-group ">
                                        <label for="inputPassword2" class="sr-only">Search</label>
                                        <input type="search" name="search" class="form-control" id="inputPassword2"
                                            placeholder="Search...">
                                    </div>
                                </form> --}}


                            </div>  
                            <div class="col-sm-4">
                                <div class="text-sm-right">
                                    <button type="button" class="btn btn-success waves-effect waves-light mb-2 mr-1"><i
                                            class="mdi mdi-cog"></i></button>
                                    <a type="button" class="btn btn-danger waves-effect waves-light mb-2"
                                        href="{{ URL::previous() }}">Back</a>
                                </div>
                            </div><!-- end col-->
                        </div>
 
                           

                    </div> <!-- end card-body-->
                </div> <!-- end card-->

                    @foreach ($projectBuyerSeller as $item)
                    <div class="card-box mb-2"> 
                        <div class="row align-items-center">
                            @if (session()->has('error'))
                            <div class="alert alert-danger">
                                {{ session()->get('error') }} </div>
                        @endif
                            <div class="col-sm-3">
                                <div class="media">
                                    @if (File::exists($projectTeams->project_image))
                                        <img src="{{ $projectTeams->project_image }}" alt="table-user"
                                            class="d-flex align-self-center mr-3 rounded-circle" controls preload="none" height="64"/>
                                    @else
                                        <img src="{{ url('') }}/assets/images/users/no.png" alt="table-user"
                                            class="d-flex align-self-center mr-3 rounded-circle" controls preload="none" height="64"/>
                                    @endif
                                    
                                    <div class="media-body">
                                        <h4 class="mt-0 mb-2 font-15">{{ $projectTeams->project_name }}</h4>
                                        <p class="mb-1"><b>Location:</b> {{ $projectTeams->location }}</p>
                                        <p class="mb-0"><b>Category:</b> {{ $projectTeams->project_category }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <p class="mb-1 mt-3 mt-sm-0"><i class="mdi mdi-email mr-1"></i> {{ $projectTeams->email }}
                                </p>
                                <p class="mb-0"><i class="mdi mdi-phone-classic mr-1"></i>
                                    {{ $projectTeams->contact_number }}</p>
                            </div>
                            <div class="col-sm-3">
                                <div class="text-center mt-3 mt-sm-0 d-flex"> 
                                    
                                    {{-- <div class="badge font-14 bg-soft-info text-info p-1"> --}}
                                        <p class="mb-1 text-capitalize"><b>Lead Name:</b>
                                            {{ $item->lead_name }}</p>
                                        
                                    {{-- </div>   --}}
                                </div>
                            </div>
                            <div class="col-sm-3">
                                {{-- <div class="text-sm-right">
                                    <a href="{{ url('edit-project/' . $projectTeams->id) }}" class="action-icon">
                                        <i class="mdi mdi-square-edit-outline">
                                        </i></a>
                                    <a href="{{ url('/project-delete/' . $projectTeams->id) }}" class="action-icon"> <i
                                            class="mdi mdi-delete"></i></a>
                                </div> --}}
                            </div> <!-- end col-->
                        </div> <!-- end row -->
                        <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                            {{-- {{ $projectTeams->links('pagination::bootstrap-4'); }} --}}
                        </ul>
                    </div> <!-- end card-box-->
                @endforeach
                
            </div> <!-- end col -->


        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection


@section('scripts')
    {{-- modal in latavel --}}
    {{-- <script>
        $(document).ready(function() {
            $(document).on('click', '.updateStatus', function() {
                var lead_id = $(this).val();
                // alert(lead_id);

                $('#lead_id').val(lead_id)
                $('#exampleModal').modal('show');


            })
        })
    </script> --}}
    {{-- modal in latavel End --}}
@endsection
