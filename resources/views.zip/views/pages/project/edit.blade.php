@extends('main')




@section('dynamic_page')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Home</a></li>
                            <li class="breadcrumb-item active">Project</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Edit Project</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-end">
                            <a type="button" class="btn btn-danger waves-effect waves-light  "
                                href="{{ url('project') }}">Back</a>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                @if (Session::has('success'))
                                    <div class="alert alert-success alert-dismissible">
                                        <h5>{{ Session::get('success') }}</h5>
                                    </div>
                                @endif
                                <form method="post" action="{{ route('update-project', $project->id) }}"
                                    enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Project Name <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="project_name" id="simpleinput"
                                                    placeholder="Project Name" class="form-control"
                                                    value="{{ $project->project_name }}">
                                                @error('project_name')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Registration Email <span
                                                        class="text-danger">*</span></label>
                                                <input type="email" name="email" id="example-email" name="example-email"
                                                    class="form-control" placeholder="Email"
                                                    value="{{ $project->email }}">
                                                @error('email')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="contactNumber">Registration Contact Number <span
                                                        class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" placeholder="Contact Number" name="contact_number"
                                                        id="contactNumber" class="form-control"
                                                        value="{{ $project->contact_number }}"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                </div>
                                                @error('contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="contactNumber">Alternate Contact Number <span
                                                        class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" placeholder="Contact Number"
                                                        name="alternate_contact_number" id="contactNumber"
                                                        class="form-control"
                                                        value="{{ $project->alternate_contact_number }}"
                                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                </div>
                                                @error('alternate_contact_number')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="example-email">Category <span
                                                        class="text-danger">*</span></label>
                                                <select class="selectpicker" data-style="btn-light"
                                                    name="project_category">
                                                    <option selected="">Select Category</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                                @error('project_category')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="Sector">Sector <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" name="sector" id="Sector" class="form-control"
                                                        placeholder="Enter your Sector" value="{{ $project->sector }}">
                                                </div>
                                                @error('sector')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="location">Location <span class="text-danger">*</span></label>
                                                <select name="location" class="selectpicker" data-style="btn-light"
                                                    id="example-select">
                                                    @foreach ($locations as $locations)
                                                        @if ($locations->location == $project->location)
                                                            <option value="{{ $locations->location }}" selected>
                                                                {{ $locations->location }}
                                                            </option>
                                                        @else
                                                            <option value="{{ $locations->location }}">
                                                                {{ $locations->location }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                @error('location')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                @php
                                                    $selected = explode(',', $project->project_type);
                                                @endphp
                                                <label for="example-select">Project Type</label>
                                                <select name="project_type[]" class="selectpicker" data-style="btn-light"
                                                    id="example-select" multiple> 
                                                    @foreach ($projectTypes as $projectType)
                                                    <option value="{{ $projectType->project_type }}"
                                                        {{ in_array($projectType->project_type, $selected) ? 'selected' : '' }}>
                                                        {{ $projectType->project_type }}</option>
                                                        {{-- @if ($projectType->project_type == $project->project_type)
                                                            <option value="{{ $projectType->project_type }}" selected>
                                                                {{ $projectType->project_type }}</option>
                                                        @endif
                                                        <option value="{{ $projectType->project_type }}">
                                                            {{ $projectType->project_type }}</option> --}}
                                                    @endforeach
                                                </select>
                                                @error('project_type')
                                                    <small class="text-danger">{{ $message }}</small>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label for="simpleinput">Rera Number</label>
                                                <input type="text" name="rera_number" class="form-control"
                                                    value="{{ $project->rera_number }}">
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group mb-3">
                                                <label for="contactNumber">Project Logo</label>
                                                <div class="input-group input-group-merge">
                                                    <input name="project_image" type="file"
                                                        value="{{ $project->project_image }}" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <table>
                                        <tr>
                                            <td style="width:50%">
                                                <hr />
                                            </td>
                                            <td style="vertical-align:middle; text-align: center">
                                                <h3 class="text-muted">Team</h3>
                                            </td>
                                            <td style="width:47%">
                                                <hr />
                                            </td>
                                        </tr>
                                    </table>
                                    <div>

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Team Name<span
                                                            class="text-danger">*</span></label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" placeholder="Enter Team Name" name="team_name"
                                                            class="form-control" value="{{ $teams->team_name }}">

                                                    </div>
                                                    @error('team_name')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Team Email</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" placeholder="Enter Team Name" name="team_email"
                                                            class="form-control" value="{{ $teams->team_email }}">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Team Phone Number</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" placeholder="Enter Team Phone number"
                                                            name="team_phone_number" class="form-control"
                                                            value="{{ $teams->team_phone_number }}"
                                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">

                                                        @error('team_phone_number')
                                                            <small class="text-danger">{{ $message }}</small>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Alternate Contact Number <span
                                                            class="text-danger">*</span></label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" placeholder="Contact Number"
                                                            name="alternate_contact_number_team" id="contactNumber"
                                                            class="form-control"
                                                            value="{{ $teams->alternate_contact_number_team }}"
                                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" pattern="[1-9]{1}[0-9]{9}">
                                                    </div>
                                                    @error('alternate_contact_number_team')
                                                        <small class="text-danger">{{ $message }}</small>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Date of birth</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="date" name="date_of_birth" class="form-control"
                                                            value="{{ $teams->date_of_birth }}">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Wedding Anniversary</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="date" name="wedding_anniversary" class="form-control"
                                                            value="{{ $teams->wedding_anniversary }}">
                                                    </div>
                                                </div>
                                            </div>
                                            {{-- <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="contactNumber">Designation</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" placeholder="Designation" name="designation"
                                                            class="form-control">
                                                    </div>
                                                </div>
                                            </div> --}}
                                        </div>
                                    </div>

                                    <hr>






                                    {{-- <div class="custom-control custom-switch">
                                        <input name="project_status" type="checkbox" class="custom-control-input"
                                            id="customSwitch1">
                                        <label class="custom-control-label" for="customSwitch1">Activate</label>
                                    </div> --}}

                            </div>




                            <button name="submit" value="submit" type="submit"
                                class="mt-4 btn btn-primary waves-effect waves-light">
                                Update</button>



                            </form>
                        </div>
                    </div>



                </div> <!-- end card-body-->

            </div>


        </div> <!-- end col -->

    </div>
    <!-- end row -->

    </div> <!-- container -->
@endsection

@section('script')
@endsection
