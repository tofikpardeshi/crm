@extends('main')
<!-- Start Content-->

@section('dynamic_page')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    {{-- <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">CRM</a></li>
                            <li class="breadcrumb-item active">Opportunities</li>
                        </ol>
                    </div> --}}
                    <h4 class="page-title">Project</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->


        <div class="row">
            <div class="col-xl-8 order-xl-1 order-2">
                <div class="card mb-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-8">
                                {{-- <form class="form-inline">
                                    <div class="form-group">
                                        <label for="inputPassword2" class="sr-only">Search</label>
                                        <input type="search" class="form-control" id="inputPassword2"
                                            placeholder="Search...">
                                    </div>
                                    <div class="form-group mx-sm-3">
                                        <label for="status-select" class="mr-2">Sort By</label>
                                        <select class="custom-select" id="status-select">
                                            <option selected="">All</option>
                                            <option value="1">Hot</option>
                                            <option value="2">Cold</option>
                                            <option value="3">In Progress</option>
                                            <option value="4">Lost</option>
                                            <option value="5">Won</option>
                                        </select>
                                    </div>
                                </form> --}}
                                {{-- <form class="form-inline" method="get" 
                                action="{{ url('search-project') }}">
                                    <div class="form-group mb-2">
                                        <label for="inputPassword2" class="sr-only">Search</label>
                                        <input type="search" name="search" class="form-control" id="inputPassword2"
                                            placeholder="Search...">
                                    </div>
                                </form> --}}
                            </div>
                            <div class="col-lg-4">
                                <div class="text-lg-right mt-3 mt-lg-0">
                                    <a href="{{ url('project') }}">
                                        {{-- <button type="button" class="btn btn-success waves-effect waves-light mr-1"><i
                                                class="mdi mdi-cog"></i></button> --}}
                                        <button type="button" class="btn btn-danger waves-effect waves-light"
                                            data-toggle="modal" data-target="#custom-modal"><i
                                                class="mdi mdi-plus-circle mr-1"></i>Back</button>
                                    </a>
                                </div>
                            </div><!-- end col-->
                        </div> <!-- end row -->
                    </div> <!-- end card-body-->

                   
                </div> <!-- end card-->

                @foreach ($projectTeams as $projectTeam)
                    <div class="card-box mb-2">
                        <div class="row align-items-center">
                            @if (session()->has('error'))
                            <div class="alert alert-danger">
                                {{ session()->get('error') }} </div>
                        @endif
                            <div class="col-sm-4">
                                <div class="media">
                                    @if (File::exists($projectTeam->project_image))
                                        <img src="{{ $projectTeam->project_image }}" alt="table-user"
                                            class="d-flex align-self-center mr-3 rounded-circle" controls preload="none" height="64"/>
                                    @else
                                        <img src="{{ url('') }}/assets/images/users/no.png" alt="table-user"
                                            class="d-flex align-self-center mr-3 rounded-circle" controls preload="none" height="64"/>
                                    @endif
                                    
                                    <div class="media-body">
                                        <h4 class="mt-0 mb-2 font-15">{{ $projectTeam->project_name }}</h4>
                                        <p class="mb-1"><b>Location:</b> {{ $projectTeam->location }}</p>
                                        <p class="mb-0"><b>Category:</b> {{ $projectTeam->project_category }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <p class="mb-1 mt-3 mt-sm-0"><i class="mdi mdi-email mr-1"></i> {{ $projectTeam->email }}
                                </p>
                                <p class="mb-0"><i class="mdi mdi-phone-classic mr-1"></i>
                                    {{ $projectTeam->contact_number }}</p>
                            </div>
                            <div class="col-sm-3">
                                <div class="text-center mt-3 mt-sm-0 d-flex">
                                    <a href="{{ url('project-details/'.$projectTeam->id.'/'. 1) }}">
                                    <div class="badge font-14 bg-soft-info text-info p-1">
                                        Buyer  {{ App\Models\Lead::where('project_id',$projectTeam->id)
                                        ->where('buyer_seller',1)
                                        ->select('buyer_seller')->count(); }}
                                    </div> 
                                </a>

                                <a href="{{ url('project-details/'.$projectTeam->id.'/'. 2) }}">
                                    <div class="badge font-14 bg-soft-info text-info p-1 mx-2">
                                        Seller  {{ App\Models\Lead::where('project_id',$projectTeam->id)
                                        ->where('buyer_seller',2)
                                        ->select('buyer_seller')->count(); }}
                                    </div> 
                                </a>

                                <a href="{{ url('project-details/'.$projectTeam->id.'/'. 3) }}">
                                    <div class="badge font-14 bg-soft-info text-info p-1">
                                        Buyer & Seller  {{ App\Models\Lead::where('project_id',$projectTeam->id)
                                        ->where('buyer_seller',3)
                                        ->select('buyer_seller')->count(); }}
                                    </div> 
                                </a>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="text-sm-right">
                                    <a href="{{ url('edit-project/' . $projectTeam->id) }}" class="action-icon">
                                        <i class="mdi mdi-square-edit-outline">
                                        </i></a>
                                    <a href="{{ url('project-delete/' . $projectTeam->id) }}" class="action-icon"> <i
                                            class="mdi mdi-delete"></i></a>
                                </div>
                            </div> <!-- end col-->
                        </div> <!-- end row -->
                        <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                            {{-- {{ $projectTeams->links('pagination::bootstrap-4'); }} --}}
                        </ul>
                    </div> <!-- end card-box-->
                @endforeach

 
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div> <!-- container -->
@endsection
