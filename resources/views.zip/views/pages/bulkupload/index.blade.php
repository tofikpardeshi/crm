@extends('main')


@section('dynamic_page')
    <!-- Start Content-->
    <!-- Start Content-->
    <div class="row ">
        <div class="col-lg-12">
            @if (isset($errors) && $errors->any())
                <div class="alert alert-danger text-center mt-4">
                    @foreach ($errors->all() as $error)
                        
                        
                        @if ($error == "The file field is required.")
                        {{ $error }} 
                        @elseif($error == "There was an error on row 2. The email_id has already been taken.")
                        {{ $error }} 
                        @else
                        {{-- {{ $error }}  --}}
                         {{ "Invalid Format " }}
                         
                         {{-- <a href="{{ asset('storage/sample/Homents Client Tracking Sheet.xlsx') }}" download>
                            <button class="btn btn-info" >sample excel</button>
                        </a>  --}}
                        @break  
                        @endif
                    @endforeach  
                @endif
                 
            @if (Session::has('excel'))
                <div class="alert alert-success alert-dismissible text-center">
                    <h5>{{ Session::get('excel') }}</h5>
                </div>
            @endif
            {{-- @if (session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}  
                </div>
            @endif --}}

        </div>
    </div>
    <div class="container-fluid">

        

        <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Homents</a></li>
                        <li class="breadcrumb-item active">Bulk Data</li>
                    </ol>
                </div>
                <h4 class="page-title">Bulk Data</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-sm-4">
                            <a href="{{ asset('storage/sample/Leads.xlsx') }}" download>
                                <button class="btn btn-info" >Sample excel</button>
                            </a>
                            {{-- <form class="form-inline">
                                <div class="form-group mb-2">
                                    <label for="inputPassword2" class="sr-only">Search</label>
                                    <input type="search" class="form-control" id="inputPassword2" placeholder="Search...">
                                </div>
                            </form> --}}
                        </div>
                        <div class="col-sm-8">
                            <div class="text-sm-right"> 
                                <form action="lead-upload" method="post" enctype="multipart/form-data">
                                    @csrf
                                    
                                    <div class="form-gorup">
                                        <input type="file" name="file">
                                        <button type="submit" name="submit" value="submit"
                                            class="btn btn-success waves-effect waves-light mb-2"
                                            href="{{ route('lead-upload') }}">Import</button>
                                    </div> 
                                </form>  
                            </div>

                            

                            
                        </div><!-- end col-->
                    </div>

                    <div class="table-responsive">
                        @if (session()->has('Delete'))
                            <div class="alert alert-danger text-center">
                                {{ session()->get('Delete') }} </div>
                        @endif
                        @if (session()->has('success'))
                            <div class="alert alert-success text-center">
                                {{ session()->get('success') }} </div>
                        @endif

                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Customer Name</th> 
                                    <th>Contact Number</th> 
                                    <th>Customer Requirement</th>
                                    <th>Buying Location</th>
                                    <th>Source</th>
                                    <th>Lead Status</th>
                                    <th>Lead Type</th>
                                    <th>Number of Units</th>
                                    <th>Customer Type</th>
                                    {{-- <th>Contact Number</th>
                                        <th>Source</th>
                                        <th>Project Type</th>
                                        <th>Assigned To</th>
                                        <th>Lead Status</th> --}}
                                    {{-- <th style="width: 82px;">Action</th> --}}
                                </tr>
                            </thead>
                            <tbody>
                                {{-- @foreach ($ClientSheets as $ClientSheet)
                                    <tr>
                                        <td class="table-user">
                                             <img src="{{ url('') }}/assets/images/users/user-4.jpg" alt="table-user"
                                            class="mr-2 rounded-circle"> 
                                            <a href="#" class="text-body font-weight-semibold"
                                                value="{{ $ClientSheet->id }}">{{ $ClientSheet->name_of_client }}</a>
                                        </td>
                                        <td>
                                            {{ \Carbon\Carbon::parse($ClientSheet->lead_generation_date)->format('j-F-Y') }}
                                        </td>
                                        <td>
                                            {{ \Carbon\Carbon::parse($ClientSheet->created_at)->format('j-F-Y') }}

                                        </td>
                                        <td>
                                            {{ $ClientSheet->budget }}
                                        </td>
                                        <td>

                                            <a href="{{ url('/edit-leads/' . $ClientSheet->id) }}" class="action-icon">
                                                <i class="mdi mdi-square-edit-outline">
                                                </i></a> 
                                            <a href="{{ url('/lead-delete/' . $ClientSheet->id) }}" class="action-icon">
                                                <i class="mdi mdi-delete"></i></a> 


                                        </td>
                                    </tr>
                                @endforeach --}}

                                  @foreach ($LeadSheets as $LeadSheet)
                                    <tr>
                                        <td>{{ $LeadSheet->date }}</td>
                                        <td class="table-user">
                                             {{-- <img src="{{ url('') }}/assets/images/users/user-4.jpg" alt="table-user"
                                            class="mr-2 rounded-circle">  --}}
                                            <a href="#" class="text-body font-weight-semibold"
                                                value="{{ $LeadSheet->id }}">{{ $LeadSheet->lead_name }}</a>
                                        </td>
                                        <td>
                                            {{ ($LeadSheet->contact_number) }}
                                        </td>
                                        <td>
                                            {{ ($LeadSheet->project_type) }}
                                        </td>
                                        <td>
                                            {{ $LeadSheet->location_of_leads }}

                                        </td> 
                                        <td>
                                            {{ $LeadSheet->source }}
                                        </td>

                                        <td>
                                            {{ $LeadSheet->lead_status }}
                                        </td>
                                        <td>
                                            {{ $LeadSheet->lead_type_bifurcation }}
                                        </td>
                                        <td>
                                            {{ $LeadSheet->number_of_units }}
                                        </td>

                                        <td>
                                            {{ $LeadSheet->property_requirement }}
                                        </td>
                                        
                                        <td>

                                            {{-- <a href="{{ url('/edit-leads/' . $ClientSheet->id) }}" class="action-icon">
                                                <i class="mdi mdi-square-edit-outline">
                                                </i></a> 
                                            <a href="{{ url('/lead-delete/' . $ClientSheet->id) }}" class="action-icon">
                                                <i class="mdi mdi-delete"></i></a>  --}}


                                        </td>
                                    </tr>
                                @endforeach 
                            </tbody>
                        </table>

                    </div>

                    <ul class="pagination pagination-rounded justify-content-end mb-0 mt-2">
                        {{ $ClientSheets->links('pagination::bootstrap-4') }}
                    </ul>

                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->


    </div>
    <!-- end row -->
    </div> 
    </div> <!-- container -->
@endsection
