 
      


            <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu">

                <div class="h-100" data-simplebar>

                    <!-- User box -->
                    <div class="user-box text-center">
                        <img src="assets/images/users/user-1.jpg" alt="user-img" title="Mat Helme"
                            class="rounded-circle avatar-md">
                        <div class="dropdown">
                            <a href="javascript: void(0);" class="text-dark dropdown-toggle h5 mt-2 mb-1 d-block"
                                data-toggle="dropdown">{{ Auth::user()->name }}</a>
                            <div class="dropdown-menu user-pro-dropdown">

                                <!-- item-->
                                <a href="{{ route('admin-profile') }}" class="dropdown-item notify-item">
                                    <i class="fe-user mr-1"></i>
                                    <span>My Account</span>
                                </a>

                                <!-- item-->
                                <a href="{{ route('admin-setting') }}" class="dropdown-item notify-item">
                                    <i class="fe-settings mr-1"></i>
                                    <span>Settings</span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <i class="fe-lock mr-1"></i>
                                    <span>Lock Screen</span>
                                </a>

                                <!-- item-->
                                {{-- <a href="{{ url('logout') }}" class="dropdown-item notify-item">
                                    <i class="fe-log-out mr-1"></i>
                                    <span>Logout</span>
                                </a> --}}

                            </div>
                        </div>
                        <p class="text-muted">Admin Head</p>
                    </div>

                    @php
                        $role_id =  Auth::user()->roles_id;
                        $rolePermission = DB::table('roles')->where('id',$role_id)
                        ->select("roles.name")->first();

                        $users = App\Models\User::role("Manager")->get();
                         // dd($users);
                    @endphp
                        
                    <!--- Sidemenu -->
                    <div id="sidebar-menu">

                        <ul id="side-menu">

                            {{-- @hasrole($users)
                                I am a writer!
                            @else
                                I am not a writer...
                            @endhasrole  --}}
                
                              {{-- @role('Manager')  --}}
                            <li class="menuitem-active">
                                <a class="active" href="{{ route('dashboard') }}">
                                    <i class="mdi mdi-view-dashboard-outline"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('employees-index') }}">
                                    <i class="mdi mdi-account-multiple-outline"></i>
                                    <span> Employees </span>
                                </a>
                            </li>
                            {{-- @else   --}}
                            <li>
                                <a href="{{ route('project-index') }}">
                                    <i class="mdi mdi-briefcase-check-outline"></i>
                                    <span> Projects </span>
                                </a>
                            </li>
                            
                            <li>
                                <a href="{{ route('leads-index') }}">
                                    <i class="mdi mdi-poll"></i>
                                    <span> Leads </span>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('bulk-upload') }}">
                                    <i class="fa fa-upload" aria-hidden="true"></i>
                                    <span> Bulk Upload </span>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('common-pool') }}">
                                    <i class="fab fa-creative-commons"></i>
                                    <span> Common Pool </span>
                                </a>
                            </li>
                            
                            <li>
                                <a href="{{ route('role-index') }}">
                                    <i class="mdi mdi-layers-outline"></i>
                                    <span> Roles </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ Route('location') }}">
                                    <i class="mdi mdi-book-account-outline"></i>
                                    <span> Location </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('admin-setting') }}">
                                    <i class="mdi mdi-cog"></i>
                                    <span> Settings </span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('admin-profile') }}">
                                    <i class="mdi mdi-account-circle-outline"></i>
                                    <span> Profile </span>
                                </a>
                            </li>
                              {{-- @endrole   --}}


                           
                           
                            <li>
                                <a href="{{ url('logout') }}">
                                    <i class="mdi mdi-logout"></i>
                                    <span> Logout </span>
                                </a>
                            </li>

                           

                           
                        </ul>

                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

           