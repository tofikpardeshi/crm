<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;
    protected $fillable = [
        'project_name',
        'email',
        'project_category',
        'location',
        'sector',
        'contact_number',
        'project_type',
        'assign_mumbers',
        // 'project_image',
        // 'project_status'
    ];
}
