<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeadSheet extends Model
{
    use HasFactory;

    protected $fillable = [
        'date',
        'lead_name',
        'contact_number',
        'project_type',
        'location_of_leads',
        'source',
        'lead_status',
        'lead_type_bifurcation',
        'number_of_units',
        'property_requirement',
    ];
}
