<?php

namespace App\Imports;

use App\Models\LeadSheet;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\SkipsOnError; 
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Maatwebsite\Excel\Concerns\WithValidation;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class LeadsImport implements ToModel ,WithHeadingRow,SkipsOnError,WithValidation
{
    use Importable, SkipsErrors;
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new LeadSheet([  
                'date'=> \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['date'])->format('d-m-Y'),
                'lead_name' => $row['lead_name'], 
                'contact_number' => $row['contact_number'],
                'project_type' => $row['project_type'],
                'location_of_leads' => $row['location_of_leads'],
                'source' => $row['source'],
                'lead_status' => $row['lead_status'],
                'lead_type_bifurcation' => $row['lead_type_bifurcation'],
                'number_of_units' => $row['number_of_units'],
                'property_requirement' => $row['property_requirement'],  
        ]);
    }

    public function onError(\Throwable $e)
    {
        // Handle the exception how you'd like.
    }

    public function rules(): array
    {
        return [  
            '*.lead_name' => 'required',
        ];
         
    } 
}
